# Koi 终端（KoiTerm）

一个 APK 二合一：**Root 伪终端（PTY）** + **带 root 的文件管理器**。
界面按你给的参考图做成深色「Koi 终端控制台」：三栏底部导航（文件执行 / 文件管理 / 设置）。

## 功能

### 终端（文件执行页）
- `libkoipty.so`（`forkpty`）真 PTY 伪终端：`isatty()=true`，`vim` / `top` / `htop` / 交互式脚本都能跑，双向交互。
- **执行方式可切换（管道选项）**：`执行方式 · PTY 伪终端` ⇄ `执行方式 · 管道 Pipe`
  - **PTY 伪终端**（默认）：`forkpty`，有 TTY，`vim` / `top` / 颜色 / 窗口尺寸 / `readline` 全正常。
  - **管道 Pipe**：普通 `ProcessBuilder` 直通，兼容性最好，无 TTY 依赖；某些 ROM 的 su 在 PTY 下行为异常时选这个。管道模式没有提示符刷新和窗口尺寸，`vim`/`top` 会花屏，属预期。
  - 选择会记忆（SharedPreferences `koi.use_pty`），PTY 创建失败也会自动降级到管道并在终端里打印 `[提示]`。
- native 加载失败自动降级为管道模式，不会白屏。
- 「启动二进制」：填绝对路径（也可点「选择」在目录里挑），自动 `chmod 755`，在二进制所在目录启动。
- 「启动 Root Shell」：直接拉起 `su`（KernelSU → `/data/adb/ksu/bin/su`，Magisk → `/data/adb/magisk/su`），PATH 已包含 ksu/magisk 目录。
- 管道模式下 root shell 走 `su -c "/system/bin/sh -i"`，PTY 模式下直接拉起 `su`。
- 中断 `^C`、清屏、`TAB`、执行历史（↑/↓ 也走历史）、退出码回填状态条。
- **终端区可滚动**：终端文本不再 `textIsSelectable`（否则触摸被选择手势吃掉，ScrollView 滚不动）；新增「复制全部」按钮；小窗/分屏下终端区保留 110dp 最小高度。
- **启动二进制前校验**：路径先清洗（去掉粘贴带来的反斜杠/引号/零宽字符），再用 `su -c "test -f"` 判断存在性（无存储权限时 Java 看不到 `/sdcard`）。
- **从文件管理直接执行**：文件菜单里「在终端执行」→ 自动切到文件执行页、填入路径并启动。
- **键盘不挡输入框**：`setDecorFitsSystemWindows(false)` + `WindowInsets.ime` 监听，键盘弹出时内容区顶起、底部导航自动隐藏。
- 输入框用普通 `text` 输入类型（之前的 `textVisiblePassword` 会触发输入法私密键盘、无联想）。
- 输出做了 ANSI 转义过滤 + `\r`/`\b` 处理，进度条不会刷成乱码。

### 文件管理
- 目录浏览：`/sdcard`、`/data`、`/` 一键跳转，上级、刷新，隐藏文件可见。
- **属性 / 权限**：点「属性」看 Java 侧信息 + `ls -ld` / `stat -c` 的权限位、属主:属组、大小、mtime（root 时 `/data` 里的文件也能看）。
- **解压 zip**：点 zip 文件可选「解压到当前目录」或「解压到 <同名>/ 子目录」；多选后点「解压」批量解压。先走 Java `ZipInputStream`（带 zip-slip 防护），失败自动退 `unzip`/`busybox unzip`。
- **查看/编辑文本**：点 `.txt/.md/.log/.conf/.json/.xml/.sh/.prop` 等直接进编辑器，可改可存（`onBackPressed` 会提示未保存），超过 2 MB 只读提示。
- **复制 / 移动 / 粘贴 / 重命名 / 删除 / 新建目录**，**目录递归复制**（`cp -a`，整棵树一步到位）。
- 长按多选，操作在子线程执行，完成后自动刷新。
- 读不到就自动转 `su`：`/data`、`/data/adb`、`/system` 这些目录同样能列、能拷、能删。
- 文件详情弹窗里可直接「chmod 755 后去终端执行」。

### 共享存储执行（exit 126）

`/sdcard`、`/storage`、`/mnt` 在 Android 上是 **noexec**，FUSE 也不支持 `chmod`，直接 `exec` 会返回 **126**。
`ExecHelper` 的处理链：

1. 路径不在共享存储 → `chmod 755` 后按 ELF 直接 `exec`
2. 路径在共享存储 → `cp -af` 到 `/data/local/tmp/koi_bin/` 并 `chmod 755`，在副本上执行（终端里会打印 `[提示] 已在 tmp 执行副本`）
3. 非 ELF（`.sh` 等）→ 用 `/system/bin/sh <path>` 解释执行，不需要可执行位

手动兜底：在终端输入 `sh '/sdcard/.../脚本.sh'`。

### 权限
- 启动时请求 root（触发管理器授权弹窗）并回显：`Root 已授权 · KernelSU · su=/data/adb/ksu/bin/su`。
- Android 11+ 申请「所有文件访问」（MANAGE_EXTERNAL_STORAGE），设置页可重试。

## 目录结构

```
app/src/main/cpp/pty.c                 forkpty → JNI（真伪终端）
app/src/main/java/com/koi/term/
  term/PtyBridge.kt                    JNI 声明
  term/TerminalSession.kt              会话（PTY / 管道双后端）+ 单例保活
  term/TerminalBuffer.kt               ANSI 过滤 + 行缓冲
  root/RootManager.kt                  su 检测、su -c 执行、引号转义
  file/FileOps.kt                      列目录 / cp / mv / rm / mkdir / chmod（root 自动降级）
  ui/TerminalFragment.kt               终端页
  ui/FilesFragment.kt                  文件管理页
  ui/SettingsFragment.kt               环境与权限页
```

## 编译

**方式 A：Android Studio（推荐）**
1. Android Studio (Hedgehog+) → `Open` → 选 `KoiTerm` 目录。
2. 首次同步会自动下载 Gradle 8.7、AGP 8.5.2、NDK/CMake。
3. `Build → Build Bundle(s)/APK(s) → Build APK(s)`。
4. 产物：`app/build/outputs/apk/debug/app-debug.apk`。

> SDK Manager 里需要装：**NDK (Side by side) 26.x**、**CMake 3.22.1**、Android 14 (API 34) Platform。
> 若提示找不到 wrapper，终端跑一次 `gradle wrapper --gradle-version 8.7` 再同步。

**方式 B：命令行**
```bash
export ANDROID_HOME=$HOME/Android/Sdk
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

**方式 C：GitHub Actions 出带 PTY 的包（最省事，推荐）**

仓库里已带 `.github/workflows/build.yml`，会自动装 NDK 26.1 + CMake 3.22.1，默认 `-PkoiPty=true`，因此产物里含 `lib/arm64-v8a/libkoipty.so`（真伪终端）。

手机上的完整操作：

1. 浏览器打开 github.com → 右上 `+` → **New repository** → 名字 `KoiTerm` → Private/Public 都行 → **Create**。
2. 进入新仓库 → `Add file` → **Upload files** → 把解压后的 `KoiTerm` 文件夹里的**全部内容**拖进去
   （手机 Chrome 支持拖文件夹；也可以先传 `KoiTerm-src.zip` 再在网页里不行——zip 不会被解压，所以必须传文件夹内容）。
   - 至少要有：`app/`、`gradle/`、`build.gradle.kts`、`settings.gradle.kts`、`gradle.properties`、`.github/`
   - **不要**传 `local.properties`（里面是本机路径，仓库已 gitignore）
3. 提交后点 **Actions** 标签 → 左侧 `Build KoiTerm APK` → 等 6~10 分钟（NDK 编译三个任务里最久的一步）。
4. 跑完点进这次 run → 页面底部 **Artifacts** → 下载 `KoiTerm-debug-apk.zip`
   （GitHub 的 artifact 永远是 zip，即使里面只有一个 apk，用文件管理器解压即可）。
5. 装：解压出的 `app-debug.apk` 点开安装，允许"未知来源"。

流程里内置了两道校验：`Verify libkoipty.so is inside the APK` 与 `apksigner verify`。
如果第一步就红，看是不是 `ndk;26.1.10909125` 版本名变了（去 SDK Manager 网页确认 r26b 的最新 revision 号）。

> 私有仓库也能用 Actions；只有下载 artifact 需要登录。免费额度：私有仓库 2000 分钟/月，单次 10 分钟内绰绰有余。

## 在手机上直接编译（本机已验证可用）

这台手机（aarch64 + proot Ubuntu）已跑通完整构建链，**不需要电脑**。可复现脚本：`/root/opt/bin/build-koi-apk.sh`。

关键点（照抄即可复刻）：

1. **JDK 17**：`apt-get install -y openjdk-17-jdk-headless`
2. **Gradle 8.7**：腾讯镜像 `https://mirrors.cloud.tencent.com/gradle/gradle-8.7-bin.zip`
   - 官方 `bin/gradle` 在 proot 下会因 manifest classpath 解析失败报 `NoClassDefFoundError: org/slf4j/LoggerFactory`，
     改用全量 classpath 启动：`java -cp "$G/lib/*" org.gradle.launcher.GradleMain`
3. **Android SDK**：腾讯镜像 `https://mirrors.cloud.tencent.com/AndroidSDK/`
   - `build-tools_r34-linux.zip` → `build-tools/34.0.0`
   - `platform-34-ext12_r01.zip` → `platforms/android-34`，并把 `package.xml` 的 `path` 改成 `platforms;android-34`、
     删掉 `<extension-level>` / `<base-extension>`，否则 AGP 报 `Failed to find target with hash string 'android-34'`
   - 建 `licenses/android-sdk-license`、`android-sdk-preview-license`
4. **aapt2 是硬阻塞**（官方只有 x86_64）：用 Termux 的 aarch64 版，包 `aapt2` + 依赖
   （abseil-cpp / libprotobuf / fmt / libc++ / libexpat / libpng / libzopfli / zlib），解到 `/root/opt/termux`，
   再写一个 wrapper 当 build-tools 的 aapt2：
   ```sh
   #!/bin/sh
   export LD_LIBRARY_PATH=/root/opt/termux/data/data/com.termux/files/usr/lib:$LD_LIBRARY_PATH
   exec /root/opt/termux/data/data/com.termux/files/usr/bin/aapt2 "$@"
   ```
   并在 `gradle.properties` 里 `android.aapt2FromMavenOverride=<wrapper 路径>`
5. **Java 信任库**：proot 下 `$JDK/lib/security/cacerts` 是断链，需要真实文件 + `-Djavax.net.ssl.trustStore=...`
6. **NDK 不可用**：官方 NDK 不带 linux-aarch64 host 工具链，所以用 `-PkoiPty=false` 关掉 native，
   运行时 PTY 缺失会自动降级管道后端（终端页「执行方式」可以看到实际后端）
7. 构建：`/root/opt/bin/build-koi-apk.sh` → `app/build/outputs/apk/debug/app-debug.apk`

> 要 PTY 真伪终端那颗 .so，仍需在 x86_64 电脑上用 Android Studio / GitHub Actions 编一次（`-PkoiPty=true`，默认值）。

## 对抗检测（ACE / TP 这类游戏反作弊）

> 先划重点：**改 app 只解决一半**。这类反作弊是设备级扫描，另一半必须靠内核/root 侧隐藏。
> 下面分成"应用层已内置"和"设备层必须自己做"两块。

### 应用层（本工程已内置）

| 特征点 | 处理 |
|---|---|
| 应用名 | `终端控制台`（`strings.xml` 的 `app_name`） |
| 包名 | `com.sys.devsvc`（`-PappId=` 可再换，别带 term/shell/root/hack 字样） |
| Java 包名 / dex 类名 | `com.sys.devsvc.*`（无 `koi` 残留，已用 dex 字节扫描验证） |
| 原生库名 | `libcoreio.so`（不是 libkoipty 这类可识别名字） |
| 权限 | 只有 `INTERNET`；**没有**存储 / 通知 / 前台服务 / 无障碍 / 悬浮窗 |
| debuggable | release 构建显式 `isDebuggable = false`，CI 里还有一步 `aapt2 dump xmltree` 断言 |
| 签名 | 工程内 `app/kei.jks` 固定签名，每次都同签名可覆盖升级（注意：私钥随仓库公开，介意就换成自己的） |
| 最近任务 | `excludeFromRecents="true"`，任务列表里不出现 |
| 进程名 | JNI `prctl(PR_SET_NAME)` 把 `/proc/self/comm` 改成 `kworker/u16:2` 一类 |
| 线程名 | `io-reader`（去掉了 koi-/term- 前缀） |
| 临时目录 | `/data/local/tmp/.svccache`（隐藏文件，其他 App 列不出来） |
| SharedPreferences | 文件名 `cfg`，键名 `use_pty / stealth / last_dir` |
| 隐蔽模式 | 脚本以随机 10 位隐藏名落地 → 执行 → 立即 `rm` → `logcat -c`，命令行里只出现那一个随机文件 |
| 输出前缀 | `[*]`（不再有 `[koi]`） |
| PS1 | `sh:/ #`（不带品牌名） |

### 设备层（必须自己配，否则应用层做得再好也白搭）

1. **root 方案二选一**
   - **KernelSU + susfs4ksu**（推荐）：内核级隐藏 `su`、模块路径、挂载点，`/proc/mounts` 里看不到 magisk/susfs 痕迹
   - **Magisk + Zygisk + Shamiko + DenyList**：把游戏加进 DenyList，Shamiko 负责让游戏看不到 root
2. **对本应用也隐藏**：DenyList 里除了游戏，把 `com.sys.devsvc` 也加上，游戏查应用列表/进程时看不到它
3. **关开发者选项、USB 调试、无线调试**：ACE 会读 `adb_enabled`、`development_settings_enabled`
4. **别装 hook 框架**：LSPosed / Frida / Xposed 的痕迹（`/data/adb/lspd`、`frida-server` 端口）是最容易被抓的，用完卸载并重启
5. **脚本别放明显位置**：不要用 `/sdcard/外挂/`、`/sdcard/GG/` 这类目录名；放 `/data/adb/` 或走隐蔽模式（临时随机名）
6. **不要注入游戏进程**：不 `ptrace`、不改内存、不 hook —— 只要脚本是独立进程（当前实现就是），游戏侧就只剩环境检测
7. **跑完就退**：`su` 进程别常驻；隐蔽模式执行完会清 logcat，再手动 `logcat -c` 一次更稳

### 实测顺序（由上到下，从便宜到贵）

1. 装 release 包（非 debuggable）→ 看游戏能否正常启动
2. 只开 root 隐藏（susfs/Shamiko），不跑脚本 → 确认游戏不闪退
3. 跑一次性小脚本（`id`）→ 确认不触发
4. 再上真实脚本；若被检测，看是启动即退（root/环境）还是运行中才退（进程/文件/行为）

## 使用

1. 打开 App → 首次会弹 root 授权（Magisk/KernelSU/APatch），允许。
2. 文件执行页：点「启动 Root Shell」→ 就是 `ksu:/ #` 交互终端，直接敲 `ls -l /data/adb`、`id`、`busybox` 等。
3. 跑自己的 ELF：把二进制放 `/data/local/tmp`，点「选择」挑文件 → 「启动二进制」。
4. 文件管理页：长按选中 → 复制/移动 → 进目标目录 → 粘贴。

## 注意

- 应用的 root 能力完全来自系统 `su`，设备必须先 root（KernelSU/Magisk/APatch 任一）。
- `su` 授权是系统行为；被拒时终端自动退化为普通用户 shell。
- 部分 ROM 的 `su` 不接受 `-c`，此时可把 `RootManager.suPath` 指向 `/system/bin/sh` 路由或改用 `su 0`。
