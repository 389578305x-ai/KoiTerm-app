// 无 NDK 构建：-PkoiPty=false（手机端/aarch64 主机没有官方 NDK 时用，PTY 自动降级管道）
val enablePty = (project.findProperty("koiPty") as String?)?.toBoolean() ?: true

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.koi.term"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.koi.term"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        if (enablePty) {
            ndk {
                // 只编 arm64：绝大多数真机够用；要 32 位或模拟器再补 armeabi-v7a / x86_64
                abiFilters += listOf("arm64-v8a")
            }
            externalNativeBuild {
                cmake { arguments += "-DANDROID_STL=c++_static" }
            }
        }
    }

    if (enablePty) {
        externalNativeBuild {
            cmake {
                path = file("src/main/cpp/CMakeLists.txt")
                version = "3.22.1"
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug { isMinifyEnabled = false }
    }

    packaging {
        jniLibs { useLegacyPackaging = true }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
}
