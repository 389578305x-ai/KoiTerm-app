// 包名可伪装，避免出现 term/koi/hack 等敏感词：
//   gradle :app:assembleRelease -PappId=com.svc.shellbox
val appId: String = (project.findProperty("appId") as String?) ?: "com.sys.devsvc"

// 无 NDK 构建：-PkoiPty=false（本机 aarch64 无官方 NDK 时用，PTY 自动降级管道）
val enablePty = (project.findProperty("koiPty") as String?)?.toBoolean() ?: true

// release 签名：优先用传入的 keystore，否则用工程内 app/kei.jks（保证每次构建签名一致）
val keiStoreProp: String? = project.findProperty("keiStore") as String?
val keiDefault = file("kei.jks")
val keiStore: String? = keiStoreProp ?: if (keiDefault.exists()) keiDefault.absolutePath else null
val keiStorePass: String = (project.findProperty("keiStorePass") as String?) ?: "koikoi"
val keiKeyAlias: String = (project.findProperty("keiKeyAlias") as String?) ?: "koi"
val keiKeyPass: String = (project.findProperty("keiKeyPass") as String?) ?: "koikoi"

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sys.devsvc"
    compileSdk = 34

    defaultConfig {
        applicationId = appId
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        if (enablePty) {
            ndk {
                abiFilters += listOf("arm64-v8a")
            }
            externalNativeBuild {
                cmake { arguments += "-DANDROID_STL=c++_static" }
            }
        }
    }

    if (enablePty) {
        externalNativeBuild {
            cmake {
                path = file("src/main/cpp/CMakeLists.txt")
                version = "3.22.1"
            }
        }
    }

    signingConfigs {
        if (keiStore != null) {
            create("release") {
                storeFile = file(keiStore)
                storePassword = keiStorePass
                keyAlias = keiKeyAlias
                keyPassword = keiKeyPass
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isDebuggable = false
            isZipAlignEnabled = true
            signingConfig = if (keiStore != null) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        jniLibs { useLegacyPackaging = true }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
}
