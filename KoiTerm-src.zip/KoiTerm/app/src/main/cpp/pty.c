/*
 * koipty - 最小 PTY 桥
 * forkpty 出一个真终端，Java 侧用 ParcelFileDescriptor 接管 master fd，
 * 因此 su / sh / 任意 ELF 二进制都能双向交互，并且 isatty() == true。
 */
#include <jni.h>
#include <pty.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <termios.h>

static pid_t g_child = -1;

static char **to_argv(JNIEnv *env, jobjectArray arr) {
    jsize n = (*env)->GetArrayLength(env, arr);
    char **argv = (char **) calloc((size_t) n + 1, sizeof(char *));
    if (!argv) return NULL;
    for (jsize i = 0; i < n; i++) {
        jstring s = (jstring) (*env)->GetObjectArrayElement(env, arr, i);
        if (!s) { argv[i] = strdup(""); continue; }
        const char *c = (*env)->GetStringUTFChars(env, s, NULL);
        argv[i] = strdup(c ? c : "");
        (*env)->ReleaseStringUTFChars(env, s, c);
        (*env)->DeleteLocalRef(env, s);
    }
    argv[n] = NULL;
    return argv;
}

static void free_argv(char **argv) {
    if (!argv) return;
    for (char **p = argv; *p; p++) free(*p);
    free(argv);
}

JNIEXPORT jint JNICALL
Java_com_koi_term_term_PtyBridge_createPty(JNIEnv *env, jclass clazz,
                                          jobjectArray argvArr,
                                          jstring cwdStr,
                                          jint rows, jint cols) {
    char **argv = to_argv(env, argvArr);
    if (!argv || !argv[0]) { free_argv(argv); return -1; }

    const char *cwd = cwdStr ? (*env)->GetStringUTFChars(env, cwdStr, NULL) : NULL;

    struct winsize ws;
    memset(&ws, 0, sizeof(ws));
    ws.ws_row = (unsigned short) (rows > 0 ? rows : 48);
    ws.ws_col = (unsigned short) (cols > 0 ? cols : 120);

    int master = -1;
    pid_t pid = forkpty(&master, NULL, NULL, &ws);
    if (pid < 0) {
        if (cwd) (*env)->ReleaseStringUTFChars(env, cwdStr, cwd);
        free_argv(argv);
        return -1;
    }

    if (pid == 0) {
        /* child */
        if (cwd && cwd[0]) {
            if (chdir(cwd) != 0) chdir("/");
        }
        setenv("TERM", "xterm-256color", 1);
        setenv("COLORTERM", "truecolor", 1);
        setenv("LANG", "en_US.UTF-8", 1);
        setenv("PS1", "\\u@koi:\\w # ", 1);
        const char *home = getenv("HOME");
        if (!home || home[0] != '/') setenv("HOME", "/", 1);
        setenv("PATH",
               "/data/adb/ksu/bin:/data/adb/magisk:/data/adb/ap/bin:"
               "/sbin:/system/sbin:/system/bin:/system/xbin:/odm/bin:"
               "/vendor/bin:/vendor/xbin:/data/local/bin:/data/local/xbin:"
               "/product/bin:/apex/com.android.runtime/bin",
               1);
        execvp(argv[0], argv);
        _exit(127);
    }

    if (cwd) (*env)->ReleaseStringUTFChars(env, cwdStr, cwd);
    free_argv(argv);

    g_child = pid;
    fcntl(master, F_SETFD, 0);
    return (jint) master;
}

JNIEXPORT void JNICALL
Java_com_koi_term_term_PtyBridge_setWindowSize(JNIEnv *env, jclass clazz,
                                               jint fd, jint rows, jint cols) {
    if (fd < 0) return;
    struct winsize ws;
    memset(&ws, 0, sizeof(ws));
    ws.ws_row = (unsigned short) rows;
    ws.ws_col = (unsigned short) cols;
    ioctl(fd, TIOCSWINSZ, &ws);
}

JNIEXPORT jint JNICALL
Java_com_koi_term_term_PtyBridge_getChildPid(JNIEnv *env, jclass clazz) {
    return (jint) g_child;
}

JNIEXPORT jint JNICALL
Java_com_koi_term_term_PtyBridge_waitFor(JNIEnv *env, jclass clazz, jint pid) {
    if (pid <= 0) return -1;
    int status = 0;
    if (waitpid((pid_t) pid, &status, 0) < 0) return -1;
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    if (WIFSIGNALED(status)) return -WTERMSIG(status);
    return -1;
}
