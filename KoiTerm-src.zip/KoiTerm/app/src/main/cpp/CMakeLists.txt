cmake_minimum_required(VERSION 3.22.1)
project(koipty C)

add_library(koipty SHARED pty.c)

find_library(log-lib log)
target_link_libraries(koipty ${log-lib})
