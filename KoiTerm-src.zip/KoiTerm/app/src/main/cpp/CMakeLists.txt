cmake_minimum_required(VERSION 3.22.1)
project(coreio C)

add_library(coreio SHARED pty.c)

find_library(log-lib log)
target_link_libraries(coreio ${log-lib})
