package com.sys.devsvc.ui

import android.content.Context
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sys.devsvc.R
import com.sys.devsvc.file.ExecHelper
import com.sys.devsvc.file.FileEntry
import com.sys.devsvc.file.FileOps
import com.sys.devsvc.file.Stealth
import com.sys.devsvc.root.RootManager
import com.sys.devsvc.term.TerminalBuffer
import com.sys.devsvc.term.TerminalSession
import java.io.File

class TerminalFragment : Fragment(R.layout.fragment_terminal) {

    private lateinit var tvTerm: TextView
    private lateinit var scroll: ScrollView
    private lateinit var etBin: EditText
    private lateinit var etCmd: EditText
    private lateinit var tvPrompt: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btnMode: Button

    private val buffer = TerminalBuffer()
    private val history = ArrayList<String>()
    private var histIndex = -1
    private var session: TerminalSession? = null

    /** 执行方式：true = PTY 伪终端，false = 管道 Pipe */
    private var usePty = true

    /** 隐蔽模式：脚本落地随机名、执行后自删、清 logcat */
    private var stealth = false

    private val listener = object : TerminalSession.Listener {
        override fun onOutput(text: String) {
            val v = view ?: return
            v.post { buffer.feed(text); render() }
        }

        override fun onExit(code: Int) {
            val v = view ?: return
            v.post {
                buffer.feed("\n[进程结束] exit=$code\n")
                render()
                tvStatus.text = "● 会话已结束（exit=$code）· ${session?.backendName ?: ""}"
                updateButtons()
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        tvTerm = view.findViewById(R.id.tvTerminal)
        scroll = view.findViewById(R.id.scrollTerm)
        etBin = view.findViewById(R.id.etBin)
        etCmd = view.findViewById(R.id.etCmd)
        tvPrompt = view.findViewById(R.id.tvPrompt)
        tvStatus = view.findViewById(R.id.tvStatus)
        btnMode = view.findViewById(R.id.btnMode)

        usePty = prefs().getBoolean("use_pty", true)
        stealth = prefs().getBoolean("stealth", false)
        updateModeButton()
        updateStealthButton()

        session = TerminalSession.Holder.session
        session?.listener = listener
        if (session?.isRunning() == true) {
            tvStatus.text = "● 已连接运行中的会话（${session!!.backendName}）"
        } else {
            tvStatus.text = "● 等待启动 · root=${if (RootManager.granted) RootManager.managerName else "未授权"}"
        }

        btnMode.setOnClickListener { toggleMode() }
        view.findViewById<Button>(R.id.btnStealth).setOnClickListener { toggleStealth() }
        view.findViewById<Button>(R.id.btnRunBin).setOnClickListener { startBinary() }
        view.findViewById<Button>(R.id.btnRunShell).setOnClickListener { startShell() }
        view.findViewById<Button>(R.id.btnStop).setOnClickListener { stopSession() }
        view.findViewById<Button>(R.id.btnIntr).setOnClickListener { sendRaw("\u0003") }
        view.findViewById<Button>(R.id.btnClear).setOnClickListener {
            buffer.clear(); render()
        }
        view.findViewById<Button>(R.id.btnTab).setOnClickListener { sendRaw("\t") }
        view.findViewById<Button>(R.id.btnHist).setOnClickListener { showHistory() }
        view.findViewById<Button>(R.id.btnPick).setOnClickListener { pickBinary() }
        view.findViewById<Button>(R.id.btnSend).setOnClickListener { sendLine() }

        etCmd.setOnEditorActionListener { _, actionId, event ->
            val isEnter = actionId == EditorInfo.IME_ACTION_SEND ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP)
            if (isEnter) { sendLine(); true } else false
        }
        etCmd.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> { historyPrev(); return@setOnKeyListener true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { historyNext(); return@setOnKeyListener true }
                }
            }
            false
        }

        render()
        view.post { applyPtySize() }
    }

    override fun onDestroyView() {
        session?.listener = null
        super.onDestroyView()
    }

    private fun prefs() =
        requireContext().getSharedPreferences("cfg", Context.MODE_PRIVATE)

    private fun updateModeButton() {
        btnMode.text = if (usePty) "执行方式 · PTY 伪终端" else "执行方式 · 管道 Pipe"
        btnMode.setTextColor(
            if (usePty) 0xFFAFA0FF.toInt() else 0xFFFFC86B.toInt()
        )
    }

    private fun updateStealthButton() {
        val b = view?.findViewById<Button>(R.id.btnStealth) ?: return
        b.text = if (stealth) "隐蔽模式 · 开（随机名/自删/清日志）" else "隐蔽模式 · 关"
        b.setTextColor(if (stealth) 0xFF3DDC84.toInt() else 0xFFEDEDF2.toInt())
    }

    private fun toggleStealth() {
        stealth = !stealth
        prefs().edit().putBoolean("stealth", stealth).apply()
        updateStealthButton()
        toast(
            if (stealth) "已开启：脚本以随机隐藏名落在 /data/local/tmp，执行后删除并清 logcat"
            else "已关闭隐蔽模式"
        )
    }

    private fun toggleMode() {
        usePty = !usePty
        prefs().edit().putBoolean("use_pty", usePty).apply()
        updateModeButton()
        val hint = if (usePty) {
            "已切到 PTY：支持 vim/top/颜色/窗口尺寸"
        } else {
            "已切到管道：最兼容，但无 TTY（vim/top 会异常），下次启动生效"
        }
        tvStatus.text = "● 等待启动 · 执行方式=${if (usePty) "PTY" else "管道"}"
        toast(hint)
    }

    private fun applyPtySize() {
        val s = session ?: return
        val cols = (tvTerm.width / 16).coerceAtLeast(40)
        val rows = (scroll.height / 30).coerceAtLeast(12)
        s.resize(rows, cols)
    }

    private fun render() {
        tvTerm.text = buffer.render()
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun ensureSession(): TerminalSession {
        val running = session
        if (running != null && running.isRunning()) return running
        val s = TerminalSession()
        s.listener = listener
        session = s
        TerminalSession.Holder.session = s
        return s
    }

    private fun startBinary() {
        val path = etBin.text.toString().trim()
        if (path.isEmpty()) {
            toast("先填二进制绝对路径，例如 /data/local/tmp/hello")
            return
        }
        if (!path.startsWith("/")) {
            toast("必须是绝对路径")
            return
        }
        val file = File(path)
        if (!file.exists() && !RootManager.granted) {
            toast("文件不存在：$path")
            return
        }
        val prepared = ExecHelper.prepare(path)
        val cwd = if (prepared.execPath.startsWith("/")) {
            prepared.execPath.substringBeforeLast('/', "/")
        } else {
            "/"
        }
        val cmd = if (stealth) Stealth.build(prepared.execPath, prepared.useShell)
        else ExecHelper.buildCommand(prepared)
        val argv = if (RootManager.granted) {
            arrayOf(RootManager.suPath, "-c", "$cmd; echo; echo \"[*] exit=\$?\"; sleep 1")
        } else {
            arrayOf("/system/bin/sh", "-c", cmd)
        }
        val s = ensureSession()
        buffer.clear()
        buffer.feed(
            "Console ready.\n" +
                "[系统] ${if (RootManager.granted) "Root 授权就绪" else "普通用户模式"}" +
                " · 执行方式 ${if (usePty) "PTY 伪终端" else "管道 Pipe"}\n" +
                "[执行] $path\n" +
                "[方式] ${if (prepared.useShell) "sh 解释执行" else "ELF 直接 exec"}" +
                " · ${if (stealth) "隐蔽模式" else "普通模式"}\n" +
                (prepared.notice?.let { "[提示] $it\n" } ?: "")
        )
        val ok = s.start(argv, cwd, file.name, usePty)
        val mode = s.backendName + if (s.lastError.isNotEmpty()) "（${s.lastError}）" else ""
        tvStatus.text = if (ok) "● 运行中：${file.name} · $mode" else "● 启动失败：${s.lastError}"
        if (ok && s.lastError.isNotEmpty()) buffer.feed("[提示] ${s.lastError}\n")
        tvPrompt.text = "ksu:/ #"
        render()
        updateButtons()
    }

    private fun startShell() {
        val s = ensureSession()
        val cwd = "/sdcard"
        val argv = when {
            usePty && RootManager.granted -> arrayOf(RootManager.suPath)
            usePty -> arrayOf("/system/bin/sh", "-i")
            RootManager.granted -> arrayOf(RootManager.suPath, "-c", "/system/bin/sh -i")
            else -> arrayOf("/system/bin/sh", "-i")
        }
        buffer.clear()
        buffer.feed(
            "Console ready.\n" +
                "[系统] ${if (RootManager.granted) "KernelSU/Magisk 授权就绪，支持双向交互。" else "普通用户 shell。"}" +
                "\n[执行方式] ${if (usePty) "PTY 伪终端" else "管道 Pipe（无 TTY）"}\n"
        )
        val ok = s.start(argv, cwd, "shell", usePty)
        if (ok) {
            s.write("export PATH=/data/adb/ksu/bin:/data/adb/magisk:/system/bin:/system/xbin:\$PATH\n")
            s.write("cd /sdcard 2>/dev/null\n")
            if (usePty) s.write("PS1='ksu:/ # '\n")
        }
        val mode = s.backendName + if (s.lastError.isNotEmpty()) "（${s.lastError}）" else ""
        tvStatus.text = if (ok) "● Shell 运行中 · $mode" else "● 启动失败：${s.lastError}"
        if (ok && s.lastError.isNotEmpty()) buffer.feed("[提示] ${s.lastError}\n")
        tvPrompt.text = if (RootManager.granted) "ksu:/ #" else "$:/ #"
        render()
        updateButtons()
    }

    private fun stopSession() {
        session?.stop()
        buffer.feed("\n[*] 会话已终止\n")
        render()
        tvStatus.text = "● 会话已终止"
        updateButtons()
    }

    private fun updateButtons() {
        val running = session?.isRunning() == true
        view?.findViewById<Button>(R.id.btnStop)?.isEnabled = running
        view?.findViewById<Button>(R.id.btnIntr)?.isEnabled = running
    }

    private fun sendRaw(s: String) {
        val se = session
        if (se == null || !se.isRunning()) { toast("没有运行中的会话"); return }
        se.write(s)
    }

    private fun sendLine() {
        val text = etCmd.text.toString()
        val se = session
        if (se == null || !se.isRunning()) {
            toast("先启动 Shell 或二进制")
            return
        }
        buffer.feed("\n$text")
        se.write(text + "\n")
        if (text.isNotBlank()) history.add(text)
        histIndex = history.size
        etCmd.setText("")
        render()
    }

    private fun historyPrev() {
        if (history.isEmpty()) return
        histIndex = (histIndex - 1).coerceAtLeast(0)
        etCmd.setText(history[histIndex])
        etCmd.setSelection(etCmd.text.length)
    }

    private fun historyNext() {
        if (history.isEmpty()) return
        histIndex = (histIndex + 1).coerceAtMost(history.size)
        etCmd.setText(if (histIndex >= history.size) "" else history[histIndex])
        etCmd.setSelection(etCmd.text.length)
    }

    private fun showHistory() {
        if (history.isEmpty()) { toast("暂无历史命令"); return }
        val items = history.reversed().toTypedArray()
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("执行历史")
            .setItems(items) { _, which -> etCmd.setText(items[which]); etCmd.setSelection(etCmd.text.length) }
            .setNegativeButton("清空") { _, _ -> history.clear() }
            .setPositiveButton("关闭", null)
            .show()
    }

    private var pickDialog: android.app.AlertDialog? = null
    private var currentPick = "/sdcard"

    /** 选择文件：与文件管理共用同一套目录浏览与记忆位置 */
    private fun pickBinary() {
        val view = layoutInflater.inflate(R.layout.dialog_picker, null)
        val tvP = view.findViewById<TextView>(R.id.tvPickPath)
        val rv = view.findViewById<RecyclerView>(R.id.rvPick)
        currentPick = prefs().getString("last_dir", "/sdcard").orEmpty().ifEmpty { "/sdcard" }

        lateinit var loadDir: (String) -> Unit
        val pickAdapter = FileAdapter(
            onClick = { e -> if (e.isDir) loadDir(e.path) else choose(e.path) },
            onLongClick = { e -> if (!e.isDir) choose(e.path) },
            isChecked = { false }
        )
        loadDir = { path ->
            currentPick = path
            tvP.text = path
            Thread {
                val list = try { FileOps.list(path) } catch (t: Throwable) { emptyList<FileEntry>() }
                activity?.runOnUiThread { pickAdapter.submit(list) }
            }.start()
        }
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = pickAdapter

        view.findViewById<Button>(R.id.btnPickUp).setOnClickListener { loadDir(FileOps.parentOf(currentPick)) }
        view.findViewById<Button>(R.id.btnPickSd).setOnClickListener { loadDir("/sdcard") }
        view.findViewById<Button>(R.id.btnPickData).setOnClickListener { loadDir("/data") }
        view.findViewById<Button>(R.id.btnPickTmp).setOnClickListener { loadDir("/data/local/tmp") }
        view.findViewById<Button>(R.id.btnPickRoot).setOnClickListener { loadDir("/") }

        pickDialog = android.app.AlertDialog.Builder(requireContext())
            .setTitle("选择文件（与文件管理同一目录）")
            .setView(view)
            .setNegativeButton("取消", null)
            .create()
        pickDialog?.show()
        loadDir(currentPick)
    }

    private fun choose(path: String) {
        etBin.setText(path)
        prefs().edit().putString("last_dir", FileOps.parentOf(path)).apply()
        pickDialog?.dismiss()
    }

    private fun toast(s: String) = Toast.makeText(requireContext(), s, Toast.LENGTH_SHORT).show()
}
