package com.sys.devsvc.file

data class FileEntry(
    val name: String,
    val path: String,
    val isDir: Boolean,
    val size: Long = -1L,
    val mode: String = "",
    val linkTarget: String? = null
) {
    val readableSize: String
        get() = when {
            isDir -> "目录"
            size < 0 -> "—"
            size < 1024 -> "$size B"
            size < 1024 * 1024 -> String.format("%.1f KB", size / 1024.0)
            size < 1024L * 1024 * 1024 -> String.format("%.1f MB", size / 1024.0 / 1024.0)
            else -> String.format("%.2f GB", size / 1024.0 / 1024.0 / 1024.0)
        }
}
