package com.sys.devsvc.ui

import android.content.Context
import android.view.View

/** 背景配色：6 套预设，存 SharedPreferences，各页 onResume 时应用 */
object UiTheme {

    private const val KEY = "bg_color"

    data class Preset(val name: String, val color: Int)

    val presets = listOf(
        Preset("纯黑", 0xFF000000.toInt()),
        Preset("深空", 0xFF0B0B0E.toInt()),
        Preset("黛青", 0xFF06121A.toInt()),
        Preset("墨绿", 0xFF07150F.toInt()),
        Preset("深紫", 0xFF120E1E.toInt()),
        Preset("夜蓝", 0xFF0A1020.toInt()),
        Preset("暖灰", 0xFF15130F.toInt())
    )

    fun current(ctx: Context): Int =
        ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
            .getInt(KEY, presets[1].color)

    fun set(ctx: Context, color: Int) {
        ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
            .edit().putInt(KEY, color).apply()
    }

    fun apply(root: View?) {
        root ?: return
        root.setBackgroundColor(current(root.context))
    }
}
