package com.sys.devsvc.file

import com.sys.devsvc.root.RootManager
import java.io.File

/**
 * 文件操作：先试 Java 直读（/sdcard 之类），失败自动走 su，
 * 因此 /data /system 这些目录也能浏览、复制、移动、整目录复制。
 */
object FileOps {

    /** 上一次列目录用的通道：java / root / fail，便于界面提示 */
    @Volatile
    var lastSource: String = "-"

    fun list(path: String): List<FileEntry> {
        val dir = File(path)
        val arr = try { dir.listFiles() } catch (t: Throwable) { null }
        if (arr != null) {
            lastSource = "java"
            return arr.map { f ->
                FileEntry(
                    name = f.name,
                    path = f.absolutePath,
                    isDir = f.isDirectory,
                    size = if (f.isDirectory) -1L else f.length(),
                    mode = if (f.canRead()) "r" else "-"
                )
            }.sortedWith(compareByDescending<FileEntry> { it.isDir }.thenBy { it.name.lowercase() })
        }
        return rootList(path)
    }

    private fun rootList(path: String): List<FileEntry> {
        val q = RootManager.q(path)
        val attempts = listOf(
            "ls -1A -p -- $q",
            "toybox ls -1A -p -- $q",
            "busybox ls -1A -p -- $q",
            "ls -a -- $q"
        )
        var lastErr = ""
        for (cmd in attempts) {
            val r = RootManager.run("$cmd 2>&1")
            if (r.code == 0) {
                lastSource = "root"
                val base = if (path.endsWith("/")) path else "$path/"
                return r.out.lineSequence()
                    .map { it.trimEnd('\n', '\r') }
                    .filter { it.isNotBlank() && it != "." && it != ".." }
                    .filter { !it.startsWith("ls:") && !it.contains("Permission denied") }
                    .map { line ->
                        val isDir = line.endsWith("/")
                        FileEntry(
                            name = line.removeSuffix("/"),
                            path = base + line.removeSuffix("/"),
                            isDir = isDir,
                            size = -1L
                        )
                    }
                    .sortedWith(compareByDescending<FileEntry> { it.isDir }.thenBy { it.name.lowercase() })
                    .toList()
            }
            lastErr = r.out.trim().take(160)
        }
        lastSource = "fail"
        val reason = if (!RootManager.granted) "未获得 root（若已隐藏 root，本应用不能进 DenyList）" else "su 执行失败"
        return listOf(FileEntry("⚠ $reason：" + lastErr.ifEmpty { "无输出" }, "$path/__error__", false))
    }

    fun exists(path: String): Boolean = File(path).exists() || RootManager.runSmart("test -e ${RootManager.q(path)} && echo 1").out.contains("1")

    fun mkdir(parent: String, name: String): Boolean {
        val target = join(parent, name)
        if (RootManager.granted) {
            return RootManager.run("mkdir -p -- ${RootManager.q(target)}").code == 0
        }
        return File(target).mkdirs()
    }

    fun rename(path: String, newName: String): Boolean {
        val parent = parentOf(path)
        val target = join(parent, newName)
        if (RootManager.granted) {
            return RootManager.run("mv -f -- ${RootManager.q(path)} ${RootManager.q(target)}").code == 0
        }
        return try { File(path).renameTo(File(target)) } catch (t: Throwable) { false }
    }

    fun delete(paths: List<String>): Boolean {
        if (paths.isEmpty()) return false
        if (RootManager.granted) {
            val args = paths.joinToString(" ") { RootManager.q(it) }
            return RootManager.run("rm -rf -- $args").code == 0
        }
        var ok = true
        for (p in paths) {
            val f = File(p)
            ok = ok && try { f.deleteRecursively() } catch (t: Throwable) { false }
        }
        return ok
    }

    /** 复制 / 移动，目录自动递归（cp -a / mv 一步到位）。 */
    fun transfer(srcs: List<String>, destDir: String, move: Boolean): Boolean {
        if (srcs.isEmpty()) return false
        if (RootManager.granted) {
            val args = srcs.joinToString(" ") { RootManager.q(it) }
            val cmd = if (move) "mv -f -- $args ${RootManager.q(destDir)}"
            else "cp -af -- $args ${RootManager.q(destDir)}"
            return RootManager.run(cmd).code == 0
        }
        var ok = true
        for (s in srcs) {
            ok = ok && javaTransfer(File(s), File(destDir), move)
        }
        return ok
    }

    private fun javaTransfer(src: File, destDir: File, move: Boolean): Boolean {
        return try {
            val target = File(destDir, src.name)
            if (src.canonicalPath == target.canonicalPath) return false
            if (src.isDirectory) {
                target.mkdirs()
                src.listFiles()?.forEach { child -> javaTransfer(child, target, false) }
                if (move) src.deleteRecursively()
            } else {
                src.copyTo(target, overwrite = true)
                if (move) src.delete()
            }
            true
        } catch (t: Throwable) {
            false
        }
    }

    fun chmod(path: String, mode: String): Boolean =
        RootManager.runSmart("chmod $mode -- ${RootManager.q(path)}").code == 0

    fun makeExecutable(path: String): Boolean = chmod(path, "755")

    fun parentOf(path: String): String {
        val p = path.trimEnd('/')
        val idx = p.lastIndexOf('/')
        return if (idx <= 0) "/" else p.substring(0, idx)
    }

    fun join(parent: String, name: String): String =
        if (parent.endsWith("/")) parent + name else "$parent/$name"

    fun totalSize(path: String): String {
        val res = RootManager.runSmart("du -sh -- ${RootManager.q(path)} 2>/dev/null | cut -f1")
        return res.out.trim().ifEmpty { "—" }
    }

    /** 文件属性：Java 侧信息 + shell 侧权限位（root 时能看 /data 里的文件） */
    fun stat(path: String): String {
        val q = RootManager.q(path)
        val sb = StringBuilder()
        try {
            val f = File(path)
            sb.append("路径：").append(f.absolutePath).append('\n')
            sb.append("类型：").append(if (f.isDirectory) "目录" else if (f.isFile) "文件" else "不存在").append('\n')
            if (!f.isDirectory && f.isFile) {
                sb.append("大小：").append(f.length()).append(" 字节 (").append(humanSize(f.length())).append(")\n")
            }
            sb.append("可读：").append(f.canRead())
                .append("   可写：").append(f.canWrite())
                .append("   可执行：").append(f.canExecute()).append('\n')
            val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
            sb.append("修改时间：").append(fmt.format(java.util.Date(f.lastModified()))).append('\n')
        } catch (t: Throwable) {
            sb.append("Java 侧读取受限\n")
        }
        val r = RootManager.runSmart(
            "ls -ld -- $q 2>&1; echo '---'; stat -c '权限=%a  属主=%U:%G  大小=%s  修改=%y' -- $q 2>&1"
        )
        sb.append("\n--- 权限详情 ---\n").append(r.out.trim().ifEmpty { "（无输出）" })
        return sb.toString()
    }

    fun humanSize(n: Long): String = when {
        n < 1024 -> "$n B"
        n < 1024 * 1024 -> String.format("%.1f KB", n / 1024.0)
        n < 1024L * 1024 * 1024 -> String.format("%.1f MB", n / 1024.0 / 1024.0)
        else -> String.format("%.2f GB", n / 1024.0 / 1024.0 / 1024.0)
    }

    /**
     * 解压 zip，不依赖设备上的 unzip/busybox：
     *  root 把 zip 复制到应用私有目录 -> Java 解压（app 有私有目录权限）-> root 把结果拷到目标目录。
     * 任意一步失败再退回 unzip/toybox/busybox 尝试链。
     */
    fun extractZip(ctx: android.content.Context, zipPath: String, destDir: String): Pair<Boolean, String> {
        if (RootManager.granted) {
            val tag = "ux_" + System.currentTimeMillis()
            val tmpZip = File(ctx.filesDir, "$tag.zip")
            val outDir = File(ctx.filesDir, "${tag}_out")
            try {
                val cp = RootManager.run(
                    "cp -af -- ${RootManager.q(zipPath)} ${RootManager.q(tmpZip.absolutePath)}" +
                        " && chmod 600 -- ${RootManager.q(tmpZip.absolutePath)}"
                )
                if (cp.code == 0 && tmpZip.isFile) {
                    outDir.mkdirs()
                    val base = outDir.canonicalPath
                    java.util.zip.ZipInputStream(tmpZip.inputStream().buffered()).use { zin ->
                        while (true) {
                            val e = zin.nextEntry ?: break
                            val target = File(outDir, e.name)
                            if (!target.canonicalPath.startsWith(base)) { zin.closeEntry(); continue }
                            if (e.isDirectory) target.mkdirs() else {
                                target.parentFile?.mkdirs()
                                target.outputStream().use { fos -> zin.copyTo(fos) }
                            }
                            zin.closeEntry()
                        }
                    }
                    val move = RootManager.run(
                        "mkdir -p -- ${RootManager.q(destDir)}" +
                            " && cp -af -- ${RootManager.q(outDir.absolutePath)}/. ${RootManager.q(destDir)}/"
                    )
                    if (move.code == 0) return true to "已解压到 $destDir"
                }
            } catch (t: Throwable) {
            } finally {
                try { tmpZip.delete() } catch (t: Throwable) {}
                try { outDir.deleteRecursively() } catch (t: Throwable) {}
            }
        }
        return unzipFallback(zipPath, destDir)
    }

    /** 尝试设备上可能存在的解压工具 */
    private fun unzipFallback(zipPath: String, destDir: String): Pair<Boolean, String> {
        val qz = RootManager.q(zipPath)
        val qd = RootManager.q(destDir)
        val tries = listOf(
            "mkdir -p -- $qd && cd $qd && unzip -o $qz",
            "mkdir -p -- $qd && cd $qd && toybox unzip -o $qz",
            "mkdir -p -- $qd && cd $qd && busybox unzip -o $qz",
            "mkdir -p -- $qd && cd $qd && /data/adb/magisk/busybox unzip -o $qz",
            "mkdir -p -- $qd && cd $qd && /data/adb/ksu/bin/busybox unzip -o $qz"
        )
        val errors = StringBuilder()
        for (c in tries) {
            val r = RootManager.runSmart(c)
            if (r.code == 0) return true to "已解压到 $destDir"
            errors.append(r.out.trim().take(120)).append(" | ")
        }
        return false to "解压失败（root 复制失败且设备无 unzip/busybox）：${errors.toString().take(300)}"
    }

    /** 读文本（超过上限拒绝，避免卡死 UI） */
    fun readText(path: String, maxBytes: Long = 2L * 1024 * 1024): String? {
        try {
            val f = File(path)
            if (f.isFile && f.canRead() && f.length() <= maxBytes) return f.readText()
        } catch (t: Throwable) {
        }
        val r = RootManager.run("head -c $maxBytes -- ${RootManager.q(path)} 2>/dev/null")
        return if (r.out.isNotEmpty()) r.out else null
    }

    /** 写文本：先直写，失败走 root（可写 /data、/system 之外的受限路径） */
    fun writeText(path: String, text: String): Boolean {
        try {
            File(path).writeText(text)
            return true
        } catch (t: Throwable) {
        }
        return try {
            val p = ProcessBuilder(RootManager.suPath, "-c", "cat > ${RootManager.q(path)}").start()
            p.outputStream.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            p.waitFor() == 0
        } catch (t: Throwable) {
            false
        }
    }

    private val TEXT_EXT = setOf(
        "txt", "md", "log", "conf", "cfg", "ini", "prop", "json", "xml", "yaml", "yml",
        "sh", "bash", "py", "js", "ts", "html", "css", "java", "kt", "c", "h", "cpp", "go",
        "csv", "lst", "list", "rc", "env", "gitignore", "pro"
    )

    fun isTextFile(name: String): Boolean {
        val n = name.lowercase()
        val ext = n.substringAfterLast('.', "")
        return ext in TEXT_EXT || n.startsWith(".") && ext.isEmpty()
    }
}
