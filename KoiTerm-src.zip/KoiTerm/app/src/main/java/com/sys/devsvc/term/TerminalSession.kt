package com.sys.devsvc.term

import android.os.ParcelFileDescriptor
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream

/**
 * 一条终端会话，两种后端可切换：
 *  - PTY  ：libptybridge forkpty，真伪终端，vim/top/readline/颜色/窗口尺寸全正常
 *  - PIPE ：普通 ProcessBuilder 管道，兼容性最好，但没有 TTY
 */
class TerminalSession {

    enum class Backend { PTY, PIPE }

    interface Listener {
        fun onOutput(text: String)
        fun onExit(code: Int)
    }

    @Volatile var listener: Listener? = null
    @Volatile private var running = false
    @Volatile var title: String = "sh"
        private set
    @Volatile private var _backend: Backend = Backend.PIPE
    @Volatile var lastError: String = ""
        private set

    val backend: Backend get() = _backend
    val usingPty: Boolean get() = _backend == Backend.PTY
    val backendName: String get() = if (usingPty) "PTY 伪终端" else "管道 Pipe"

    private var pfd: ParcelFileDescriptor? = null
    private var ptyFd: Int = -1
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var process: Process? = null
    private var pid: Int = -1
    private var readerThread: Thread? = null

    fun isRunning(): Boolean = running

    /**
     * @param preferPty true = 优先 PTY（创建失败自动降级管道）；false = 强制管道
     */
    fun start(argv: Array<String>, cwd: String, label: String, preferPty: Boolean = true): Boolean {
        stop()
        title = label
        lastError = ""
        if (preferPty) {
            val fd = try {
                if (PtyBridge.isAvailable()) PtyBridge.createPty(argv, cwd, 48, 120) else -1
            } catch (t: Throwable) {
                -1
            }
            if (fd >= 0) {
                pid = try { PtyBridge.getChildPid() } catch (t: Throwable) { -1 }
                ptyFd = fd
                val p = ParcelFileDescriptor.adoptFd(fd)
                pfd = p
                input = FileInputStream(p.fileDescriptor)
                output = FileOutputStream(p.fileDescriptor)
                _backend = Backend.PTY
                running = true
                startReader()
                return true
            }
            lastError = if (!PtyBridge.isAvailable()) "原生库未加载 → 管道" else "forkpty 失败 → 管道"
        }
        val ok = startPipe(argv, cwd)
        _backend = Backend.PIPE
        return ok
    }

    private fun startPipe(argv: Array<String>, cwd: String): Boolean {
        return try {
            val dir = File(cwd)
            val pb = ProcessBuilder(*argv)
            pb.directory(if (dir.isDirectory) dir else File("/"))
            pb.redirectErrorStream(true)
            val proc = pb.start()
            process = proc
            input = proc.inputStream
            output = proc.outputStream
            running = true
            startReader()
            true
        } catch (t: Throwable) {
            lastError = "启动失败：" + (t.message ?: t.javaClass.simpleName)
            false
        }
    }

    private fun startReader() {
        val ins = input ?: return
        val th = Thread {
            val buf = ByteArray(8192)
            try {
                while (running) {
                    val n = ins.read(buf)
                    if (n <= 0) break
                    listener?.onOutput(String(buf, 0, n, Charsets.UTF_8))
                }
            } catch (_: Throwable) {
            } finally {
                val code = reap()
                listener?.onExit(code)
            }
        }
        th.isDaemon = true
        th.name = "io-reader"
        readerThread = th
        th.start()
    }

    private fun reap(): Int {
        var code = -1
        try {
            if (usingPty && pid > 0) {
                code = PtyBridge.waitFor(pid)
            } else {
                process?.let { p ->
                    val end = System.currentTimeMillis() + 1500
                    while (System.currentTimeMillis() < end) {
                        try { code = p.exitValue(); break } catch (e: IllegalThreadStateException) {
                            try { Thread.sleep(40) } catch (ignored: InterruptedException) {}
                        }
                    }
                }
            }
        } catch (_: Throwable) {
        }
        closeAll()
        return code
    }

    private fun closeAll() {
        running = false
        try { input?.close() } catch (_: Throwable) {}
        try { output?.close() } catch (_: Throwable) {}
        try { pfd?.close() } catch (_: Throwable) {}
        try { process?.destroy() } catch (_: Throwable) {}
        input = null
        output = null
        pfd = null
        process = null
        ptyFd = -1
    }

    fun write(data: String) {
        val o = output ?: return
        try {
            o.write(data.toByteArray(Charsets.UTF_8))
            o.flush()
        } catch (_: Throwable) {
        }
    }

    /** 只有 PTY 后端支持窗口尺寸；管道模式静默忽略。 */
    fun resize(rows: Int, cols: Int) {
        if (usingPty && ptyFd >= 0) {
            try { PtyBridge.setWindowSize(ptyFd, rows, cols) } catch (_: Throwable) {}
        }
    }

    fun stop() {
        val p = pid
        pid = -1
        closeAll()
        if (p > 0) {
            try {
                Runtime.getRuntime().exec(arrayOf("/system/bin/sh", "-c", "kill -9 $p 2>/dev/null"))
            } catch (_: Throwable) {
            }
        }
    }

    /** 全局单例，切页面不丢会话。 */
    object Holder {
        var session: TerminalSession? = null
    }
}
