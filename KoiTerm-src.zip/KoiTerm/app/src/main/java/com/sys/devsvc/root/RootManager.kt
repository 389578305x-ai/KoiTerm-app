package com.sys.devsvc.root

import java.io.File

data class ShellResult(val code: Int, val out: String)

/** Root（Magisk / KernelSU / APatch）授权与命令执行。 */
object RootManager {

    @Volatile var granted: Boolean = false
        private set

    @Volatile var managerName: String = "未知"
        private set

    val suPath: String
        get() = when {
            File("/data/adb/ksu/bin/su").exists() -> "/data/adb/ksu/bin/su"
            File("/data/adb/magisk/su").exists() -> "/data/adb/magisk/su"
            File("/system/xbin/su").exists() -> "/system/xbin/su"
            File("/system/bin/su").exists() -> "/system/bin/su"
            else -> "su"
        }

    fun detectManager(): String = when {
        File("/data/adb/ksu").exists() -> "KernelSU"
        File("/data/adb/magisk").exists() -> "Magisk"
        File("/data/adb/ap").exists() -> "APatch"
        else -> "未知"
    }

    /** 触发一次 su 授权弹窗并校验 uid=0。会阻塞，请放子线程。 */
    fun check(): Boolean {
        granted = try {
            val p = ProcessBuilder(suPath, "-c", "id").redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            val ok = waitFor(p, 8_000) && out.contains("uid=0")
            if (ok) managerName = detectManager()
            ok
        } catch (t: Throwable) {
            false
        }
        return granted
    }

    fun run(command: String, timeoutSec: Long = 20): ShellResult = try {
        val p = ProcessBuilder(suPath, "-c", command).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        val done = waitFor(p, timeoutSec * 1000)
        ShellResult(if (done) p.exitValue() else -1, out)
    } catch (t: Throwable) {
        ShellResult(-1, t.message ?: "exec failed")
    }

    /** 不经过 root 的普通命令（/system/bin/sh）。 */
    fun runAsUser(command: String, timeoutSec: Long = 15): ShellResult = try {
        val p = ProcessBuilder("/system/bin/sh", "-c", command).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        val done = waitFor(p, timeoutSec * 1000)
        ShellResult(if (done) p.exitValue() else -1, out)
    } catch (t: Throwable) {
        ShellResult(-1, t.message ?: "exec failed")
    }

    /** 有 root 用 su，没有就退回 sh。 */
    fun runSmart(command: String): ShellResult =
        if (granted) run(command) else runAsUser(command)

    private fun waitFor(p: Process, timeoutMs: Long): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            try {
                p.exitValue()
                return true
            } catch (e: IllegalThreadStateException) {
                try { Thread.sleep(40) } catch (ignored: InterruptedException) {}
            }
        }
        return false
    }

    /** shell 单引号转义。 */
    fun q(s: String): String = "'" + s.replace("'", "'\\''") + "'"
}
