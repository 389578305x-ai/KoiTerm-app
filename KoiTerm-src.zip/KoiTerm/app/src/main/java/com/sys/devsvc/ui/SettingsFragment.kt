package com.sys.devsvc.ui

import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.sys.devsvc.R
import com.sys.devsvc.root.RootManager
import com.sys.devsvc.term.PtyBridge

class SettingsFragment : Fragment(R.layout.fragment_settings) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val tv = view.findViewById<TextView>(R.id.tvEnv)

        fun refresh() {
            tv.text = buildString {
                append("应用：终端控制台 1.0\n")
                append("包名：").append(requireContext().packageName).append('\n')
                append("设备：").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
                append("Android：").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
                append("ABI：").append(Build.SUPPORTED_ABIS.joinToString()).append('\n')
                append("root：").append(if (RootManager.granted) "已授权 · ${RootManager.managerName}" else "未授权").append('\n')
                append("su 路径：").append(RootManager.suPath).append('\n')
                append("原生库：").append(if (PtyBridge.isAvailable()) "已加载（PTY 可用）" else "未加载（管道降级）").append('\n')
                append("共享存储：通过 root 读写（未申请存储权限）\n")
            }
        }
        refresh()

        view.findViewById<Button>(R.id.btnRootCheck).setOnClickListener {
            Toast.makeText(requireContext(), "正在请求 su...", Toast.LENGTH_SHORT).show()
            Thread {
                RootManager.check()
                activity?.runOnUiThread { refresh() }
            }.start()
        }
    }
}
