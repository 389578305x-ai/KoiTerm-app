package com.sys.devsvc.ui

import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.sys.devsvc.R
import com.sys.devsvc.root.RootManager
import com.sys.devsvc.term.PtyBridge

class SettingsFragment : Fragment(R.layout.fragment_settings) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val tv = view.findViewById<TextView>(R.id.tvEnv)

        fun refresh() {
            tv.text = buildString {
                append("应用：终端控制台 1.0\n")
                append("包名：").append(requireContext().packageName).append('\n')
                append("设备：").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
                append("Android：").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
                append("ABI：").append(Build.SUPPORTED_ABIS.joinToString()).append('\n')
                append("root：").append(if (RootManager.granted) "已授权 · ${RootManager.managerName}" else "未授权").append('\n')
                append("su 路径：").append(RootManager.suPath).append('\n')
                append("原生库：").append(if (PtyBridge.isAvailable()) "已加载（PTY 可用）" else "未加载（管道降级）").append('\n')
                append("共享存储：通过 root 读写（未申请存储权限）\n")
            }
        }
        refresh()

        view.findViewById<Button>(R.id.btnSelfCheck).setOnClickListener {
            Toast.makeText(requireContext(), "自检中...", Toast.LENGTH_SHORT).show()
            Thread {
                val report = selfCheck()
                activity?.runOnUiThread { showReport(report) }
            }.start()
        }

        view.findViewById<Button>(R.id.btnRootCheck).setOnClickListener {
            Toast.makeText(requireContext(), "正在请求 su...", Toast.LENGTH_SHORT).show()
            Thread {
                RootManager.check()
                activity?.runOnUiThread { refresh() }
            }.start()
        }
    }

    private fun showReport(text: String) {
        val tv = TextView(requireContext()).apply {
            this.text = text
            setTextIsSelectable(true)
            textSize = 10f
            typeface = android.graphics.Typeface.MONOSPACE
            setTextColor(0xFFD8D8E2.toInt())
            setPadding(40, 24, 40, 24)
        }
        val sc = ScrollView(requireContext()).apply { addView(tv) }
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("环境自检")
            .setView(sc)
            .setPositiveButton("关闭", null)
            .setNeutralButton("复制") { _, _ ->
                val cm = requireContext().getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                        as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("selfcheck", text))
                Toast.makeText(requireContext(), "已复制", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun selfCheck(): String {
        val sb = StringBuilder()
        fun add(title: String, cmd: String) {
            sb.append("\n── ").append(title).append(" ──\n")
            val out = try { RootManager.runSmart(cmd).out.trim() } catch (t: Throwable) { "执行异常: ${t.message}" }
            sb.append(out.ifEmpty { "(无输出)" }.take(500)).append('\n')
        }
        add("su 身份（应为 uid=0）", "id")
        add("su 路径", "ls -l /system/bin/su /system/xbin/su 2>/dev/null; which su")
        add("/sdcard 目录前 8 项", "ls -1A /sdcard 2>&1 | head -8")
        add("root 痕迹", "grep -oE 'magisk|KernelSU|susfs|ksu' /proc/mounts 2>/dev/null | sort -u | head -6")
        add("调试开关（0=关闭更安全）", "getprop ro.debuggable; settings get global adb_enabled 2>/dev/null; settings get global development_settings_enabled 2>/dev/null")
        add("hook 框架痕迹", "ls -d /data/adb/lspd /data/adb/modules/zygisk_lsposed 2>/dev/null; ls /data/local/tmp 2>/dev/null | grep -iE 'frida|gadget'")
        add("/sdcard 高特征目录", "ls -1 /sdcard 2>/dev/null | grep -Ei 'gg|mod|hack|script|脚本|外挂|辅助' | head -10")
        return sb.toString()
    }
}
