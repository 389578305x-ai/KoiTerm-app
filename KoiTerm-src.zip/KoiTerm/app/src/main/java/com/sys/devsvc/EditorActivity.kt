package com.sys.devsvc

import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.sys.devsvc.file.FileOps

class EditorActivity : AppCompatActivity() {

    private lateinit var et: EditText
    private lateinit var tvPath: TextView
    private lateinit var tvInfo: TextView
    private var path: String = ""
    private var dirty = false
    private var original: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editor)
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        et = findViewById(R.id.etContent)
        tvPath = findViewById(R.id.tvEditorPath)
        tvInfo = findViewById(R.id.tvEditorInfo)

        path = intent.getStringExtra("path").orEmpty()
        tvPath.text = path
        if (path.isEmpty()) {
            Toast.makeText(this, "未指定文件", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val text = FileOps.readText(path)
        if (text == null) {
            tvInfo.text = "读取失败（文件可能过大或权限不足）"
            et.setText("")
            et.isEnabled = false
        } else {
            original = text
            et.setText(text)
            tvInfo.text = "${text.length} 字符 · ${FileOps.humanSize(text.toByteArray().size.toLong())}"
        }
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        et.setOnFocusChangeListener { _, has -> if (has) window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE) }

        findViewById<Button>(R.id.btnSave).setOnClickListener { save() }
        findViewById<Button>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnWrap).setOnClickListener {
            // 切换自动换行：用是否允许横向滚动近似表达
            et.setHorizontallyScrolling(false)
            Toast.makeText(this, "已开启自动换行", Toast.LENGTH_SHORT).show()
        }
    }

    private fun save() {
        val text = et.text.toString()
        val ok = FileOps.writeText(path, text)
        if (ok) {
            original = text
            dirty = false
            tvInfo.text = "已保存 · ${text.length} 字符"
            Toast.makeText(this, "已保存 $path", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "保存失败：权限不足（试试用 root shell 写）", Toast.LENGTH_LONG).show()
        }
    }

    override fun onBackPressed() {
        if (et.text.toString() != original) {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("未保存")
                .setMessage("内容已修改，是否保存后退出？")
                .setPositiveButton("保存并退出") { _, _ -> save(); finish() }
                .setNeutralButton("放弃修改") { _, _ -> finish() }
                .setNegativeButton("取消", null)
                .show()
        } else {
            super.onBackPressed()
        }
    }
}
