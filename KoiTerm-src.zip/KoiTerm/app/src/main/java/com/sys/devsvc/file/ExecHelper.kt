package com.sys.devsvc.file

import com.sys.devsvc.root.RootManager
import java.io.File

/**
 * 判断"这个文件到底该怎么执行"，并绕开 Android 上两个经典坑：
 *  1) /sdcard 是 noexec，chmod 无效 -> 复制到 /data/local/tmp 再跑
 *  2) 名字叫 .sh 不代表是 sh 脚本（很多 loader 是"脚本头 + ELF 主体"），
 *     用 root 读前 4 字节魔数判断，别靠扩展名
 */
object ExecHelper {

    private const val STAGE_DIR = "/data/local/tmp/.svccache"

    fun inSharedStorage(path: String): Boolean =
        path.startsWith("/sdcard") || path.startsWith("/storage") || path.startsWith("/mnt")

    /** 真实类型：elf / shell / text / unknown（用 root 读魔数，app 无权限时也能判断） */
    fun detectKind(path: String): String {
        val q = RootManager.q(path)
        val r = RootManager.run("head -c 4 -- $q 2>/dev/null | od -An -tx1 | tr -d ' \\n'")
        val hex = r.out.trim().lowercase()
        if (hex.startsWith("7f454c46")) return "elf"
        if (hex.isEmpty()) return "unknown"
        // 文本：首字节是可打印 ASCII 或 #!
        val first = hex.take(2)
        return if (first == "23") "shell" else "text"
    }

    data class Prepared(
        val execPath: String,
        val kind: String,
        val notice: String?
    )

    fun prepare(path: String): Prepared {
        var target = path
        var notice: String? = null

        if (inSharedStorage(path)) {
            val safeName = File(path).name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val dest = "$STAGE_DIR/$safeName"
            val res = RootManager.run(
                "mkdir -p $STAGE_DIR && cp -af -- ${RootManager.q(path)} ${RootManager.q(dest)} && chmod 755 -- ${RootManager.q(dest)}"
            )
            if (res.code == 0) {
                target = dest
                notice = "共享存储为 noexec，已复制到 $dest 执行"
            } else {
                notice = "复制到 $STAGE_DIR 失败：${res.out.trim().take(120)}"
            }
        } else {
            RootManager.runSmart("chmod 755 -- ${RootManager.q(path)}")
        }

        val kind = detectKind(target)
        return Prepared(target, kind, notice)
    }

    /**
     * 生成执行命令：
     *  elf  -> 直接 exec
     *  其它 -> sh 解释；mksh 语法不过就换 busybox sh / toybox sh，
     *          都不行才回到 sh（并把错误暴露出来）
     */
    fun buildCommand(p: Prepared): String {
        val q = RootManager.q(p.execPath)
        if (p.kind == "elf") return "exec $q"
        return buildString {
            append("if /system/bin/sh -n $q 2>/dev/null; then /system/bin/sh $q; ")
            append("else ")
            append("bb=$(command -v busybox || echo /data/adb/magisk/busybox); ")
            append("if [ -n \"\$bb\" ] && [ -x \"\$bb\" ]; then \$bb sh $q; ")
            append("else echo '[*] 不是标准 sh 脚本（可能含 bash 语法或二进制数据），尝试直接执行'; ")
            append("chmod 755 $q 2>/dev/null; $q; fi; ")
            append("fi")
        }
    }
}
