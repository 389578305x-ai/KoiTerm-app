package com.sys.devsvc.file

import com.sys.devsvc.root.RootManager
import java.io.File

/**
 * 处理 Android 上最常见的"执行不了"：
 *  - /sdcard、/storage、/mnt 是 noexec + FUSE 不支持 chmod → exit 126
 *  做法：把文件复制到 /data/local/tmp/.svccache（可执行分区）并 chmod 755。
 *  - .sh 脚本没有可执行位也没关系，直接用 /system/bin/sh 解释执行。
 */
object ExecHelper {

    private const val STAGE_DIR = "/data/local/tmp/.svccache"

    /** 共享存储判定 */
    fun inSharedStorage(path: String): Boolean =
        path.startsWith("/sdcard") || path.startsWith("/storage") || path.startsWith("/mnt")

    /** 是否 ELF 可执行文件（读文件头 4 字节，读不到就看扩展名） */
    fun isElf(path: String): Boolean {
        val name = path.substringAfterLast('/').lowercase()
        if (name.endsWith(".sh") || name.endsWith(".bash") || name.endsWith(".txt")) return false
        return try {
            val f = File(path)
            if (!f.isFile) return false
            val head = f.inputStream().use { ins ->
                val b = ByteArray(4)
                if (ins.read(b) == 4) b else null
            }
            head != null && head[0] == 0x7f.toByte() &&
                head[1] == 'E'.code.toByte() && head[2] == 'L'.code.toByte() && head[3] == 'F'.code.toByte()
        } catch (t: Throwable) {
            // 无读取权限时退化为按扩展名判断
            !(name.endsWith(".sh") || name.endsWith(".bash"))
        }
    }

    data class Prepared(val execPath: String, val useShell: Boolean, val notice: String?)

    /**
     * 返回真正可执行的路径与执行方式。
     */
    fun prepare(path: String): Prepared {
        val src = File(path)
        val shell = !isElf(path)

        // 已经在可执行分区：直接 chmod 755
        if (!inSharedStorage(path)) {
            RootManager.runSmart("chmod 755 -- ${RootManager.q(path)}")
            return Prepared(path, shell, null)
        }

        // 共享存储：复制到 /data/local/tmp 再跑
        val safeName = src.name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val dest = "$STAGE_DIR/$safeName"
        val res = RootManager.run(
            "mkdir -p $STAGE_DIR && cp -af -- ${RootManager.q(path)} ${RootManager.q(dest)} && chmod 755 -- ${RootManager.q(dest)}"
        )
        return if (res.code == 0) {
            Prepared(dest, shell, "已在 tmp 执行副本：$dest\n原因：共享存储为 noexec，无法直接 exec")
        } else {
            Prepared(path, shell, "复制到 $STAGE_DIR 失败：${res.out.trim()}\n改为原地解释执行")
        }
    }

    /** 组装 shell 命令 */
    fun buildCommand(p: Prepared): String {
        val q = RootManager.q(p.execPath)
        return if (p.useShell) "/system/bin/sh $q" else "exec $q"
    }
}
