package com.sys.devsvc.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import java.io.File
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sys.devsvc.EditorActivity
import com.sys.devsvc.R
import com.sys.devsvc.file.FileEntry
import com.sys.devsvc.file.FileOps
import com.sys.devsvc.root.RootManager

class FilesFragment : Fragment(R.layout.fragment_files) {

    private lateinit var rv: RecyclerView
    private lateinit var tvPath: TextView
    private lateinit var tvSel: TextView
    private lateinit var adapter: FileAdapter

    private var current = "/sdcard"
    private val checked = LinkedHashMap<String, FileEntry>()
    private var clipList: List<String> = emptyList()
    private var clipMove = false
    private var loading = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        rv = view.findViewById(R.id.rvFiles)
        tvPath = view.findViewById(R.id.tvPath)
        tvSel = view.findViewById(R.id.tvSel)

        adapter = FileAdapter(
            onClick = { e -> onEntryClick(e) },
            onLongClick = { e -> toggleCheck(e) },
            isChecked = { e -> checked.containsKey(e.path) }
        )
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = adapter

        view.findViewById<View>(R.id.btnUp).setOnClickListener {
            if (current != "/") load(FileOps.parentOf(current))
        }
        view.findViewById<View>(R.id.btnRoot).setOnClickListener { load("/") }
        view.findViewById<View>(R.id.btnSd).setOnClickListener { load("/sdcard") }
        view.findViewById<View>(R.id.btnData).setOnClickListener { load("/data") }
        view.findViewById<View>(R.id.btnDl).setOnClickListener { load("/sdcard/Download") }
        view.findViewById<View>(R.id.btnRefresh).setOnClickListener { load(current) }
        // 点路径可直接输入跳转（某些目录藏在深层，逐级点太慢）
        tvPath.setOnClickListener {
            val et = EditText(requireContext()).apply {
                setText(current)
                setSelection(text.length)
                inputType = InputType.TYPE_CLASS_TEXT
                setPadding(48, 24, 48, 24)
            }
            val box = FrameLayout(requireContext()).apply { addView(et) }
            AlertDialog.Builder(requireContext())
                .setTitle("跳转路径")
                .setView(box)
                .setPositiveButton("跳转") { _, _ ->
                    val p = et.text.toString().trim()
                    if (p.isNotEmpty()) load(p)
                }
                .setNegativeButton("取消", null)
                .show()
        }

        view.findViewById<View>(R.id.btnCopy).setOnClickListener {
            if (checked.isEmpty()) return@setOnClickListener toast("长按选择要复制的文件/目录")
            clipList = checked.keys.toList(); clipMove = false
            toast("已复制 ${clipList.size} 项到剪贴板")
        }
        view.findViewById<View>(R.id.btnMove).setOnClickListener {
            if (checked.isEmpty()) return@setOnClickListener toast("长按选择要移动的文件/目录")
            clipList = checked.keys.toList(); clipMove = true
            toast("已剪切 ${clipList.size} 项，进入目标目录后点粘贴")
        }
        view.findViewById<View>(R.id.btnPaste).setOnClickListener { paste() }
        view.findViewById<View>(R.id.btnDel).setOnClickListener { confirmDelete() }
        view.findViewById<View>(R.id.btnRename).setOnClickListener { renameDialog() }
        view.findViewById<View>(R.id.btnMkdir).setOnClickListener { mkdirDialog() }
        view.findViewById<View>(R.id.btnProps).setOnClickListener { showSelectedProps() }
        view.findViewById<View>(R.id.btnExtract).setOnClickListener { extractSelected() }

        load(current)
    }

    private fun load(requested: String) {
        if (loading) return
        // 如果传进来的是文件路径（比如从终端跳转来的），自动进入它所在目录
        var path = requested
        if (path.isNotEmpty() && path != "/") {
            val isDir = try {
                File(path).isDirectory || RootManager.run("test -d ${RootManager.q(path)} && echo __d__").out.contains("__d__")
            } catch (t: Throwable) { false }
            if (!isDir) path = FileOps.parentOf(path)
        }
        try {
            requireContext().getSharedPreferences("cfg", Context.MODE_PRIVATE)
                .edit().putString("last_dir", path).apply()
        } catch (t: Throwable) {
        }
        loading = true
        tvPath.text = path
        val p = if (path.isEmpty()) "/" else path
        Thread {
            val list = try { FileOps.list(p) } catch (t: Throwable) { emptyList<FileEntry>() }
            val root = RootManager.granted
            val src = FileOps.lastSource
            activity?.runOnUiThread {
                loading = false
                current = p
                checked.clear()
                adapter.submit(list)
                val real = FileOps.resolveReal(p)
                tvPath.text = if (real != p) "$p → $real" else p
                val dirs = list.count { it.isDir }
                val files = list.size - dirs
                tvSel.text = "共 ${list.size} 项（目录 $dirs / 文件 $files）· root=${if (root) "已授权" else "未授权"} · $src"
            }
        }.start()
    }

    private fun onEntryClick(e: FileEntry) {
        if (e.path.endsWith("/__error__")) { toast(e.name); return }
        if (checked.isNotEmpty()) { toggleCheck(e); return }
        when {
            e.isDir -> load(e.path)
            e.name.lowercase().endsWith(".zip") -> showZipDialog(e)
            FileOps.isTextFile(e.name) -> openEditor(e.path)
            else -> showFileMenu(e)
        }
    }

    private fun toggleCheck(e: FileEntry) {
        if (e.path.endsWith("/__error__")) return
        if (checked.containsKey(e.path)) checked.remove(e.path) else checked[e.path] = e
        adapter.notifyDataSetChanged()
        tvSel.text = if (checked.isEmpty()) "共 ${adapter.itemCount} 项" else "已选 ${checked.size} 项"
    }

    private fun openEditor(path: String) {
        try {
            startActivity(Intent(requireContext(), EditorActivity::class.java).putExtra("path", path))
        } catch (t: Throwable) {
            toast("打不开编辑器：${t.message}")
        }
    }

    private fun showFileMenu(e: FileEntry) {
        val actions = arrayOf("在终端执行", "属性 / 权限", "用文本编辑器打开", "复制路径", "删除")
        AlertDialog.Builder(requireContext())
            .setTitle(e.name)
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> execInTerminal(e.path)
                    1 -> showProps(e.path)
                    2 -> openEditor(e.path)
                    3 -> copyPath(e.path)
                    4 -> {
                        checked.clear(); checked[e.path] = e
                        confirmDelete()
                    }
                }
            }
            .setNegativeButton("关闭", null)
            .show()
    }

    private fun showZipDialog(e: FileEntry) {
        val base = e.name.substringBeforeLast('.').ifEmpty { "unzipped" }
        val actions = arrayOf("解压到当前目录", "解压到 $base/ 子目录", "属性 / 权限")
        AlertDialog.Builder(requireContext())
            .setTitle(e.name)
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> runExtract(e.path, current)
                    1 -> runExtract(e.path, FileOps.join(current, base))
                    2 -> showProps(e.path)
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun extractSelected() {
        val zips = checked.values.filter { it.name.lowercase().endsWith(".zip") }
        if (zips.isEmpty()) return toast("长按选中一个 .zip 再点解压")
        val dest = if (zips.size == 1) current else current
        val names = zips.joinToString("\n") { it.name }
        AlertDialog.Builder(requireContext())
            .setTitle("解压 ${zips.size} 个压缩包")
            .setMessage("目标目录：$dest\n\n$names")
            .setPositiveButton("开始") { _, _ ->
                Thread {
                    var okCount = 0
                    val msgs = StringBuilder()
                    zips.forEach { z ->
                        val sub = if (zips.size == 1) dest else FileOps.join(dest, z.name.substringBeforeLast('.'))
                        val (ok, msg) = FileOps.extractZip(requireContext(), z.path, sub)
                        if (ok) okCount++ else msgs.append(msg).append('\n')
                    }
                    activity?.runOnUiThread {
                        toast("完成 $okCount/${zips.size} 个" + if (msgs.isNotEmpty()) "；失败：$msgs" else "")
                        load(current)
                    }
                }.start()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun runExtract(zipPath: String, dest: String) {
        toast("解压中...")
        Thread {
            val (ok, msg) = FileOps.extractZip(requireContext(), zipPath, dest)
            activity?.runOnUiThread {
                toast(if (ok) msg else msg)
                load(current)
            }
        }.start()
    }

    private fun showSelectedProps() {
        val items = checked.values.toList()
        if (items.isEmpty()) {
            if (current.isNotEmpty()) showProps(current) else toast("长按选中一项再点属性")
            return
        }
        if (items.size == 1) { showProps(items[0].path); return }
        Thread {
            val sb = StringBuilder()
            var total = 0L
            items.forEach { e ->
                sb.append(e.name).append("  ").append(if (e.isDir) "目录" else e.readableSize).append('\n')
                if (e.size > 0) total += e.size
            }
            sb.append("\n合计 ").append(items.size).append(" 项 · ").append(FileOps.humanSize(total))
            activity?.runOnUiThread {
                AlertDialog.Builder(requireContext())
                    .setTitle("已选文件")
                    .setMessage(sb.toString())
                    .setPositiveButton("关闭", null)
                    .show()
            }
        }.start()
    }

    private fun showProps(path: String) {
        toast("读取属性...")
        Thread {
            val text = FileOps.stat(path)
            activity?.runOnUiThread {
                val tv = TextView(requireContext()).apply {
                    this.text = text
                    setTextIsSelectable(true)
                    setPadding(48, 32, 48, 32)
                    textSize = 11f
                    typeface = android.graphics.Typeface.MONOSPACE
                    setTextColor(0xFFD8D8E2.toInt())
                }
                val sc = android.widget.ScrollView(requireContext()).apply { addView(tv) }
                AlertDialog.Builder(requireContext())
                    .setTitle("属性")
                    .setView(sc)
                    .setPositiveButton("关闭", null)
                    .setNeutralButton("复制") { _, _ ->
                        val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("stat", text))
                        toast("已复制属性")
                    }
                    .show()
            }
        }.start()
    }

    private fun execInTerminal(path: String) {
        val act = activity as? com.sys.devsvc.MainActivity
        if (act == null) toast("无法跳转到终端") else act.execInTerminal(path)
    }

    private fun copyPath(path: String) {
        val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("path", path))
        toast("已复制路径")
    }

    private fun paste() {
        if (clipList.isEmpty()) { toast("剪贴板为空，先复制或剪切"); return }
        val dest = current
        val move = clipMove
        val srcs = clipList
        toast(if (move) "移动中..." else "复制中...")
        Thread {
            val ok = FileOps.transfer(srcs, dest, move)
            activity?.runOnUiThread {
                toast(if (ok) "完成：${srcs.size} 项 → $dest" else "失败：检查权限或同名文件")
                if (move) clipList = emptyList()
                load(dest)
            }
        }.start()
    }

    private fun confirmDelete() {
        val items = checked.keys.toList()
        if (items.isEmpty()) { toast("长按选择要删除的项"); return }
        AlertDialog.Builder(requireContext())
            .setTitle("删除确认")
            .setMessage("将递归删除 ${items.size} 项（目录连同内容）：\n\n${items.take(6).joinToString("\n")}${if (items.size > 6) "\n..." else ""}")
            .setPositiveButton("删除") { _, _ ->
                Thread {
                    val ok = FileOps.delete(items)
                    activity?.runOnUiThread {
                        toast(if (ok) "已删除 ${items.size} 项" else "删除失败")
                        checked.clear()
                        load(current)
                    }
                }.start()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun renameDialog() {
        val target = checked.values.firstOrNull()
        if (target == null) { toast("长按选择一项再重命名"); return }
        val et = EditText(requireContext()).apply {
            setText(target.name)
            inputType = InputType.TYPE_CLASS_TEXT
            setSelection(text.length)
            setPadding(48, 24, 48, 24)
        }
        val box = FrameLayout(requireContext()).apply { addView(et) }
        AlertDialog.Builder(requireContext())
            .setTitle("重命名")
            .setView(box)
            .setPositiveButton("确定") { _, _ ->
                val name = et.text.toString().trim()
                if (name.isEmpty()) return@setPositiveButton
                Thread {
                    val ok = FileOps.rename(target.path, name)
                    activity?.runOnUiThread {
                        toast(if (ok) "已重命名" else "重命名失败")
                        checked.clear()
                        load(current)
                    }
                }.start()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun mkdirDialog() {
        val et = EditText(requireContext()).apply {
            hint = "新目录名"
            inputType = InputType.TYPE_CLASS_TEXT
            setPadding(48, 24, 48, 24)
        }
        val box = FrameLayout(requireContext()).apply { addView(et) }
        AlertDialog.Builder(requireContext())
            .setTitle("新建目录 @ $current")
            .setView(box)
            .setPositiveButton("创建") { _, _ ->
                val name = et.text.toString().trim()
                if (name.isEmpty()) return@setPositiveButton
                Thread {
                    val ok = FileOps.mkdir(current, name)
                    activity?.runOnUiThread {
                        toast(if (ok) "已创建 $name" else "创建失败")
                        load(current)
                    }
                }.start()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun toast(s: String) = Toast.makeText(requireContext(), s, Toast.LENGTH_SHORT).show()
}
