package com.sys.devsvc.file

import com.sys.devsvc.root.RootManager
import java.io.File
import kotlin.random.Random

/**
 * 隐蔽执行：脚本以随机隐藏名落地到 /data/local/tmp，执行后立即删除并清 logcat。
 * 注意：所有路径都加引号，并在 cp 阶段临时 set -f，
 * 否则 Android mksh 会把文件名里的 [ ] * ? 当 glob 展开（报 inaccessible or not found）。
 */
object Stealth {

    private const val CHARS = "abcdefghijklmnopqrstuvwxyz0123456789"

    fun tag(len: Int = 10): String = buildString {
        repeat(len) { append(CHARS[Random.nextInt(CHARS.length)]) }
    }

    fun build(execPath: String, useShell: Boolean): String {
        val tmp = "/data/local/tmp/.${tag()}"
        val qsrc = RootManager.q(execPath)
        val qtmp = RootManager.q(tmp)
        val cwd = RootManager.q(File(execPath).parent ?: "/")
        val runner = if (useShell) "/system/bin/sh $qtmp" else qtmp

        return buildString {
            append("if [ ! -f ").append(qsrc).append(" ]; then ")
            append("echo \"[*] 源文件不存在，检查路径：\" ").append(qsrc).append("; ")
            append("else ")
            // 只在这一段禁用 glob，之后立刻恢复，不影响脚本自身的 *.so 之类的通配
            append("set -f; ")
            append("cp -af -- ").append(qsrc).append(' ').append(qtmp)
            append(" && chmod 700 ").append(qtmp)
            append("; set +f; ")
            append("cd ").append(cwd).append("; ")
            append(runner)
            append("; rc_x1=\$?")
            append("; rm -f ").append(qtmp)
            append("; echo \"[*] 结束 rc=\$rc_x1 · 临时文件已删\"")

            append("; fi; ")
            append("logcat -c >/dev/null 2>&1")
        }
    }
}
