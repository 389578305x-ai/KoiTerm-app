package com.sys.devsvc.file

import com.sys.devsvc.root.RootManager
import java.io.File
import kotlin.random.Random

/**
 * 隐蔽执行：脚本不长期留在磁盘上、名字随机、执行完自删并清 logcat，
 * 目的是减少 /data/local/tmp 与日志里的固定特征。
 */
object Stealth {

    private const val CHARS = "abcdefghijklmnopqrstuvwxyz0123456789"

    fun tag(len: Int = 10): String = buildString {
        repeat(len) { append(CHARS[Random.nextInt(CHARS.length)]) }
    }

    /** 返回可直接丢进 root shell 的一行命令 */
    fun build(execPath: String, useShell: Boolean): String {
        val tmp = "/data/local/tmp/.${tag()}"
        val q = RootManager.q(execPath)
        val cwd = File(execPath).parent ?: "/"
        val runner = if (useShell) "/system/bin/sh $tmp" else tmp
        return buildString {
            append("cp -af -- ").append(q).append(' ').append(tmp)
            append(" && chmod 700 ").append(tmp)
            append(" && cd ").append(RootManager.q(cwd))
            append("; ").append(runner)
            append("; rc_x1=\$?")
            append("; rm -f ").append(tmp)
            append("; logcat -c >/dev/null 2>&1")
            append("; echo \"[*] 结束 rc=\$rc_x1 · 临时文件已删 · logcat 已清\"")
        }
    }
}
