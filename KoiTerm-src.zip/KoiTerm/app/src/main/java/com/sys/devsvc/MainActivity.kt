package com.sys.devsvc

import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.snackbar.Snackbar
import com.sys.devsvc.root.RootManager
import com.sys.devsvc.term.PtyBridge
import com.sys.devsvc.ui.FilesFragment
import com.sys.devsvc.ui.SettingsFragment
import com.sys.devsvc.ui.TerminalFragment

class MainActivity : AppCompatActivity() {

    private lateinit var nav: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        nav = findViewById(R.id.bottomNav)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setupImeInsets()
        PtyBridge.disguiseProcess()

        nav.setOnItemSelectedListener { item ->
            val f: Fragment = when (item.itemId) {
                R.id.nav_terminal -> TerminalFragment()
                R.id.nav_files -> FilesFragment()
                else -> SettingsFragment()
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.container, f)
                .commit()
            true
        }

        if (savedInstanceState == null) {
            nav.selectedItemId = R.id.nav_terminal
        }

        requestRootAsync()
    }

    /** 文件管理里点「在终端执行」：切到终端页并自动填入、启动 */
    fun execInTerminal(path: String) {
        getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("pending_exec", path).apply()
        val cur = supportFragmentManager.findFragmentById(R.id.container)
        if (nav.selectedItemId == R.id.nav_terminal && cur is TerminalFragment) {
            cur.consumePendingExec()
        } else {
            nav.selectedItemId = R.id.nav_terminal
        }
    }

    /** 键盘弹出时把内容区顶到键盘上方，否则输入框会被遮住 */
    private fun setupImeInsets() {
        val root = findViewById<View>(R.id.rootMain)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, wi ->
            val sys = wi.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = wi.getInsets(WindowInsetsCompat.Type.ime())
            val imeVisible = wi.isVisible(WindowInsetsCompat.Type.ime())
            nav.visibility = if (imeVisible) View.GONE else View.VISIBLE
            val bottom = if (imeVisible) maxOf(ime.bottom, sys.bottom) else sys.bottom
            v.setPadding(0, sys.top, 0, bottom)
            wi
        }
        ViewCompat.requestApplyInsets(root)
    }


    private fun requestRootAsync() {
        Thread {
            val ok = RootManager.check()
            runOnUiThread {
                val msg = if (ok) {
                    "Root 已授权 · ${RootManager.managerName} · su=${RootManager.suPath}"
                } else {
                    "未获得 Root：终端将以普通用户运行（可在 root 管理器里授权后重启本页）"
                }
                Snackbar.make(findViewById<View>(R.id.container), msg, Snackbar.LENGTH_LONG).show()
            }
        }.start()
    }
}
