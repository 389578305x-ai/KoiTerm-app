package com.sys.devsvc.term

/**
 * 终端行缓冲。
 * 关键点：PTY 下 termios(ONLCR) 会把 \n 转成 \r\n，
 * 所以 \r 只能"光标回行首"，不能直接清空当前行，否则每行都会被吃掉。
 * 后续字符按列覆盖写入，这样进度条那种 abc\rxyz 也能正确重绘。
 */
class TerminalBuffer(private val maxLines: Int = 4000) {

    private val lines = ArrayList<String>()
    private var cur = StringBuilder()
    private var col = 0
    private var state = 0 // 0=普通 1=ESC 2=CSI 3=OSC

    fun clear() {
        lines.clear()
        cur = StringBuilder()
        col = 0
    }

    fun feed(data: CharSequence) {
        for (i in data.indices) {
            val c = data[i]
            when (state) {
                0 -> when (c) {
                    '\u001b' -> state = 1
                    '\r' -> col = 0
                    '\n' -> { commit(); col = 0 }
                    '\b' -> putBack()
                    else -> if (c.code < 0x20) Unit else write(c)
                }
                1 -> state = when (c) {
                    '[' -> 2
                    ']' -> 3
                    else -> 0
                }
                2 -> if (c in '@'..'~') state = 0
                3 -> if (c == '\u0007') state = 0
            }
        }
        trim()
    }

    private fun write(c: Char) {
        if (col < cur.length) cur.setCharAt(col, c) else cur.append(c)
        col++
    }

    private fun putBack() {
        if (col > 0) {
            col--
            if (col < cur.length) cur.setLength(col)
        }
    }

    private fun commit() {
        lines.add(cur.toString())
        cur = StringBuilder()
        col = 0
    }

    private fun trim() {
        while (lines.size > maxLines) lines.removeAt(0)
    }

    fun render(): String {
        if (lines.isEmpty()) return cur.toString()
        val tail = if (cur.isNotEmpty()) "\n" + cur else ""
        return lines.joinToString("\n") + tail
    }
}
