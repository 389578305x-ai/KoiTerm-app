package com.koi.term.term

/** libkoipty.so 的 JNI 入口：forkpty 真伪终端。 */
object PtyBridge {
    private var loaded = false

    init {
        loaded = try {
            System.loadLibrary("koipty")
            true
        } catch (t: Throwable) {
            false
        }
    }

    fun isAvailable(): Boolean = loaded

    external fun createPty(argv: Array<String>, cwd: String?, rows: Int, cols: Int): Int
    external fun setWindowSize(fd: Int, rows: Int, cols: Int)
    external fun getChildPid(): Int
    external fun waitFor(pid: Int): Int
}
