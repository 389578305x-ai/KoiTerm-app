package com.koi.term.ui

import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.koi.term.R
import com.koi.term.file.FileEntry
import com.koi.term.file.FileOps
import com.koi.term.root.RootManager

class FilesFragment : Fragment(R.layout.fragment_files) {

    private lateinit var rv: RecyclerView
    private lateinit var tvPath: TextView
    private lateinit var tvSel: TextView
    private lateinit var adapter: FileAdapter

    private var current = "/sdcard"
    private val checked = LinkedHashMap<String, FileEntry>()
    private var clipList: List<String> = emptyList()
    private var clipMove = false
    private var loading = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        rv = view.findViewById(R.id.rvFiles)
        tvPath = view.findViewById(R.id.tvPath)
        tvSel = view.findViewById(R.id.tvSel)

        adapter = FileAdapter(
            onClick = { e -> onEntryClick(e) },
            onLongClick = { e -> toggleCheck(e) },
            isChecked = { e -> checked.containsKey(e.path) }
        )
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = adapter

        view.findViewById<Button>(R.id.btnUp).setOnClickListener {
            if (current != "/") load(FileOps.parentOf(current))
        }
        view.findViewById<Button>(R.id.btnRoot).setOnClickListener { load("/") }
        view.findViewById<Button>(R.id.btnSd).setOnClickListener { load("/sdcard") }
        view.findViewById<Button>(R.id.btnData).setOnClickListener { load("/data") }
        view.findViewById<Button>(R.id.btnRefresh).setOnClickListener { load(current) }

        view.findViewById<Button>(R.id.btnCopy).setOnClickListener {
            if (checked.isEmpty()) return@setOnClickListener toast("长按选择要复制的文件/目录")
            clipList = checked.keys.toList(); clipMove = false
            toast("已复制 ${clipList.size} 项到剪贴板")
        }
        view.findViewById<Button>(R.id.btnMove).setOnClickListener {
            if (checked.isEmpty()) return@setOnClickListener toast("长按选择要移动的文件/目录")
            clipList = checked.keys.toList(); clipMove = true
            toast("已剪切 ${clipList.size} 项，进入目标目录后点粘贴")
        }
        view.findViewById<Button>(R.id.btnPaste).setOnClickListener { paste() }
        view.findViewById<Button>(R.id.btnDel).setOnClickListener { confirmDelete() }
        view.findViewById<Button>(R.id.btnRename).setOnClickListener { renameDialog() }
        view.findViewById<Button>(R.id.btnMkdir).setOnClickListener { mkdirDialog() }

        load(current)
    }

    private fun load(path: String) {
        if (loading) return
        loading = true
        tvPath.text = path
        val p = if (path.isEmpty()) "/" else path
        Thread {
            val list = try { FileOps.list(p) } catch (t: Throwable) { emptyList<FileEntry>() }
            val root = RootManager.granted
            activity?.runOnUiThread {
                loading = false
                current = p
                checked.clear()
                adapter.submit(list)
                tvPath.text = p
                tvSel.text = "共 ${list.size} 项 · root=${if (root) "已授权" else "未授权"}"
            }
        }.start()
    }

    private fun onEntryClick(e: FileEntry) {
        if (e.path.endsWith("/__error__")) {
            toast(e.name); return
        }
        if (checked.isNotEmpty()) { toggleCheck(e); return }
        if (e.isDir) {
            load(e.path)
        } else {
            showFileDialog(e)
        }
    }

    private fun toggleCheck(e: FileEntry) {
        if (e.path.endsWith("/__error__")) return
        if (checked.containsKey(e.path)) checked.remove(e.path) else checked[e.path] = e
        adapter.notifyDataSetChanged()
        tvSel.text = if (checked.isEmpty()) "共 ${adapter.itemCount} 项" else "已选 ${checked.size} 项"
    }

    private fun showFileDialog(e: FileEntry) {
        AlertDialog.Builder(requireContext())
            .setTitle(e.name)
            .setMessage("路径：${e.path}\n大小：${e.readableSize}")
            .setPositiveButton("执行") { _, _ ->
                FileOps.makeExecutable(e.path)
                toast("已 chmod 755，去终端页填路径启动")
            }
            .setNeutralButton("复制路径") { _, _ ->
                val cm = requireContext().getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("path", e.path))
                toast("已复制路径")
            }
            .setNegativeButton("关闭", null)
            .show()
    }

    private fun paste() {
        if (clipList.isEmpty()) { toast("剪贴板为空，先复制或剪切"); return }
        val dest = current
        val move = clipMove
        val srcs = clipList
        toast(if (move) "移动中..." else "复制中...")
        Thread {
            val ok = FileOps.transfer(srcs, dest, move)
            activity?.runOnUiThread {
                toast(if (ok) "完成：${srcs.size} 项 → $dest" else "失败：检查权限或同名文件")
                if (move) clipList = emptyList()
                load(dest)
            }
        }.start()
    }

    private fun confirmDelete() {
        val items = checked.keys.toList().ifEmpty { return toast("长按选择要删除的项") }
        AlertDialog.Builder(requireContext())
            .setTitle("删除确认")
            .setMessage("将递归删除 ${items.size} 项（目录连同内容）：\n\n${items.take(6).joinToString("\n")}${if (items.size > 6) "\n..." else ""}")
            .setPositiveButton("删除") { _, _ ->
                Thread {
                    val ok = FileOps.delete(items)
                    activity?.runOnUiThread {
                        toast(if (ok) "已删除 ${items.size} 项" else "删除失败")
                        checked.clear()
                        load(current)
                    }
                }.start()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun renameDialog() {
        val target = checked.values.firstOrNull() ?: return toast("长按选择一项再重命名")
        val et = EditText(requireContext()).apply {
            setText(target.name)
            inputType = InputType.TYPE_CLASS_TEXT
            setSelection(text.length)
            setPadding(48, 24, 48, 24)
        }
        val box = FrameLayout(requireContext()).apply { addView(et) }
        AlertDialog.Builder(requireContext())
            .setTitle("重命名")
            .setView(box)
            .setPositiveButton("确定") { _, _ ->
                val name = et.text.toString().trim()
                if (name.isEmpty()) return@setPositiveButton
                Thread {
                    val ok = FileOps.rename(target.path, name)
                    activity?.runOnUiThread {
                        toast(if (ok) "已重命名" else "重命名失败")
                        checked.clear()
                        load(current)
                    }
                }.start()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun mkdirDialog() {
        val et = EditText(requireContext()).apply {
            hint = "新目录名"
            inputType = InputType.TYPE_CLASS_TEXT
            setPadding(48, 24, 48, 24)
        }
        val box = FrameLayout(requireContext()).apply { addView(et) }
        AlertDialog.Builder(requireContext())
            .setTitle("新建目录 @ $current")
            .setView(box)
            .setPositiveButton("创建") { _, _ ->
                val name = et.text.toString().trim()
                if (name.isEmpty()) return@setPositiveButton
                Thread {
                    val ok = FileOps.mkdir(current, name)
                    activity?.runOnUiThread {
                        toast(if (ok) "已创建 $name" else "创建失败")
                        load(current)
                    }
                }.start()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun toast(s: String) = Toast.makeText(requireContext(), s, Toast.LENGTH_SHORT).show()
}
