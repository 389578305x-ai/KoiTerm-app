package com.koi.term.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.koi.term.R
import com.koi.term.file.FileEntry

class FileAdapter(
    private val onClick: (FileEntry) -> Unit,
    private val onLongClick: (FileEntry) -> Unit,
    private val isChecked: (FileEntry) -> Boolean
) : RecyclerView.Adapter<FileAdapter.VH>() {

    private val data = ArrayList<FileEntry>()

    fun submit(list: List<FileEntry>) {
        data.clear()
        data.addAll(list)
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val root: LinearLayout = v.findViewById(R.id.rowRoot)
        val icon: TextView = v.findViewById(R.id.tvIcon)
        val name: TextView = v.findViewById(R.id.tvName)
        val meta: TextView = v.findViewById(R.id.tvMeta)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false))

    override fun getItemCount(): Int = data.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = data[position]
        holder.icon.text = when {
            e.isDir -> "📁"
            e.name.endsWith(".sh") || e.name.endsWith(".bin") -> "⚙️"
            else -> "📄"
        }
        holder.name.text = e.name
        holder.meta.text = if (e.isDir) "目录" else e.readableSize
        val checked = isChecked(e)
        holder.root.setBackgroundColor(if (checked) 0x337C5CFF else Color.TRANSPARENT)
        holder.name.setTextColor(if (e.isDir) 0xFF9FD0FF.toInt() else 0xFFEDEDF0.toInt())
        holder.root.setOnClickListener { onClick(e) }
        holder.root.setOnLongClickListener { onLongClick(e); true }
    }
}
