package com.koi.term.term

/**
 * 极简终端行缓冲：过滤 ANSI 转义序列，处理 \r \n \b，
 * 保证 TextView 渲染出来的内容像一个终端，而不是一堆控制字符。
 */
class TerminalBuffer(private val maxLines: Int = 3000) {

    private val lines = ArrayList<String>()
    private var cur = StringBuilder()
    private var state = 0 // 0=普通 1=ESC 2=CSI 3=OSC

    fun clear() {
        lines.clear()
        cur = StringBuilder()
    }

    fun feed(data: CharSequence) {
        for (i in data.indices) {
            val c = data[i]
            when (state) {
                0 -> when {
                    c == '\u001b' -> state = 1
                    c == '\r' -> cur.setLength(0)
                    c == '\n' -> commit()
                    c == '\b' -> { if (cur.isNotEmpty()) cur.setLength(cur.length - 1) }
                    c.code < 0x20 -> Unit
                    else -> cur.append(c)
                }
                1 -> state = when (c) {
                    '[' -> 2
                    ']' -> 3
                    else -> 0
                }
                2 -> if (c in '@'..'~') state = 0
                3 -> if (c == '\u0007') state = 0
            }
        }
        trim()
    }

    private fun commit() {
        lines.add(cur.toString())
        cur = StringBuilder()
    }

    private fun trim() {
        while (lines.size > maxLines) lines.removeAt(0)
    }

    fun render(): String {
        val tail = if (cur.isNotEmpty()) "\n" + cur else ""
        return if (lines.isEmpty()) cur.toString() else lines.joinToString("\n") + tail
    }
}
