package com.koi.term.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.koi.term.R
import com.koi.term.root.RootManager
import com.koi.term.term.PtyBridge

class SettingsFragment : Fragment(R.layout.fragment_settings) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val tv = view.findViewById<TextView>(R.id.tvEnv)
        fun refresh() {
            tv.text = buildString {
                append("应用：KoiTerm 1.0\n")
                append("设备：${Build.MANUFACTURER} ${Build.MODEL}\n")
                append("Android：${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
                append("ABI：${Build.SUPPORTED_ABIS.joinToString()}\n")
                append("root：${if (RootManager.granted) "已授权 · ${RootManager.managerName}" else "未授权"}\n")
                append("su 路径：${RootManager.suPath}\n")
                append("PTY 后端：${if (PtyBridge.isAvailable()) "libkoipty 已加载" else "未加载（管道降级）"}\n")
                append("所有文件访问：${if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) (if (Environment.isExternalStorageManager()) "已开启" else "未开启") else "旧系统免申请"}\n")
            }
        }
        refresh()

        view.findViewById<Button>(R.id.btnRootCheck).setOnClickListener {
            Toast.makeText(requireContext(), "正在请求 su...", Toast.LENGTH_SHORT).show()
            Thread {
                RootManager.check()
                activity?.runOnUiThread { refresh() }
            }.start()
        }
        view.findViewById<Button>(R.id.btnAllFiles).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                            .setData(Uri.parse("package:${requireContext().packageName}"))
                    )
                } catch (t: Throwable) {
                    Toast.makeText(requireContext(), "系统不支持该设置页", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(requireContext(), "当前系统无需此权限", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
