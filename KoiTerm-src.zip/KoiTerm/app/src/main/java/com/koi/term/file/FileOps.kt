package com.koi.term.file

import com.koi.term.root.RootManager
import java.io.File

/**
 * 文件操作：先试 Java 直读（/sdcard 之类），失败自动走 su，
 * 因此 /data /system 这些目录也能浏览、复制、移动、整目录复制。
 */
object FileOps {

    fun list(path: String): List<FileEntry> {
        val dir = File(path)
        val arr = try { dir.listFiles() } catch (t: Throwable) { null }
        if (arr != null) {
            return arr.map { f ->
                FileEntry(
                    name = f.name,
                    path = f.absolutePath,
                    isDir = f.isDirectory,
                    size = if (f.isDirectory) -1L else f.length(),
                    mode = if (f.canRead()) "r" else "-",
                    linkTarget = null
                )
            }.sortedWith(compareByDescending<FileEntry> { it.isDir }.thenBy { it.name.lowercase() })
        }
        return rootList(path)
    }

    private fun rootList(path: String): List<FileEntry> {
        val res = RootManager.run("ls -1ApL -- ${RootManager.q(path)} 2>&1")
        val out = res.out
        if (res.code != 0 && out.isNotBlank() && !out.contains("\n")) {
            // 单行多为错误信息，交给上层提示
            return listOf(FileEntry("⚠ ${out.trim()}", "$path/__error__", false))
        }
        val base = if (path.endsWith("/")) path else "$path/"
        return out.lineSequence()
            .map { it.trimEnd('\n') }
            .filter { it.isNotEmpty() && it != "." && it != ".." }
            .map { line ->
                val isDir = line.endsWith("/")
                val name = line.removeSuffix("/")
                FileEntry(
                    name = name,
                    path = base + name,
                    isDir = isDir,
                    size = -1L
                )
            }
            .sortedWith(compareByDescending<FileEntry> { it.isDir }.thenBy { it.name.lowercase() })
            .toList()
    }

    fun exists(path: String): Boolean = File(path).exists() || RootManager.runSmart("test -e ${RootManager.q(path)} && echo 1").out.contains("1")

    fun mkdir(parent: String, name: String): Boolean {
        val target = join(parent, name)
        if (RootManager.granted) {
            return RootManager.run("mkdir -p -- ${RootManager.q(target)}").code == 0
        }
        return File(target).mkdirs()
    }

    fun rename(path: String, newName: String): Boolean {
        val parent = parentOf(path)
        val target = join(parent, newName)
        if (RootManager.granted) {
            return RootManager.run("mv -f -- ${RootManager.q(path)} ${RootManager.q(target)}").code == 0
        }
        return try { File(path).renameTo(File(target)) } catch (t: Throwable) { false }
    }

    fun delete(paths: List<String>): Boolean {
        if (paths.isEmpty()) return false
        if (RootManager.granted) {
            val args = paths.joinToString(" ") { RootManager.q(it) }
            return RootManager.run("rm -rf -- $args").code == 0
        }
        var ok = true
        for (p in paths) {
            val f = File(p)
            ok = ok && try { f.deleteRecursively() } catch (t: Throwable) { false }
        }
        return ok
    }

    /** 复制 / 移动，目录自动递归（cp -a / mv 一步到位）。 */
    fun transfer(srcs: List<String>, destDir: String, move: Boolean): Boolean {
        if (srcs.isEmpty()) return false
        if (RootManager.granted) {
            val args = srcs.joinToString(" ") { RootManager.q(it) }
            val cmd = if (move) "mv -f -- $args ${RootManager.q(destDir)}"
            else "cp -af -- $args ${RootManager.q(destDir)}"
            return RootManager.run(cmd).code == 0
        }
        var ok = true
        for (s in srcs) {
            ok = ok && javaTransfer(File(s), File(destDir), move)
        }
        return ok
    }

    private fun javaTransfer(src: File, destDir: File, move: Boolean): Boolean {
        return try {
            val target = File(destDir, src.name)
            if (src.canonicalPath == target.canonicalPath) return false
            if (src.isDirectory) {
                target.mkdirs()
                src.listFiles()?.forEach { child -> javaTransfer(child, target, false) }
                if (move) src.deleteRecursively()
            } else {
                src.copyTo(target, overwrite = true)
                if (move) src.delete()
            }
            true
        } catch (t: Throwable) {
            false
        }
    }

    fun chmod(path: String, mode: String): Boolean =
        RootManager.runSmart("chmod $mode -- ${RootManager.q(path)}").code == 0

    fun makeExecutable(path: String): Boolean = chmod(path, "755")

    fun parentOf(path: String): String {
        val p = path.trimEnd('/')
        val idx = p.lastIndexOf('/')
        return if (idx <= 0) "/" else p.substring(0, idx)
    }

    fun join(parent: String, name: String): String =
        if (parent.endsWith("/")) parent + name else "$parent/$name"

    fun totalSize(path: String): String {
        val res = RootManager.runSmart("du -sh -- ${RootManager.q(path)} 2>/dev/null | cut -f1")
        return res.out.trim().ifEmpty { "—" }
    }
}
