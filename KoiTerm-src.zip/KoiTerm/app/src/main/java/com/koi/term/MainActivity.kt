package com.koi.term

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.snackbar.Snackbar
import com.koi.term.root.RootManager
import com.koi.term.ui.FilesFragment
import com.koi.term.ui.SettingsFragment
import com.koi.term.ui.TerminalFragment

class MainActivity : AppCompatActivity() {

    private lateinit var nav: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        nav = findViewById(R.id.bottomNav)

        nav.setOnItemSelectedListener { item ->
            val f: Fragment = when (item.itemId) {
                R.id.nav_terminal -> TerminalFragment()
                R.id.nav_files -> FilesFragment()
                else -> SettingsFragment()
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.container, f)
                .commit()
            true
        }

        if (savedInstanceState == null) {
            nav.selectedItemId = R.id.nav_terminal
        }

        ensurePermissions()
        requestRootAsync()
    }

    private fun ensurePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                            .setData(Uri.parse("package:$packageName"))
                    )
                } catch (t: Throwable) {
                    try {
                        startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                    } catch (_: Throwable) {
                    }
                }
            }
        } else {
            val need = arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ).filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }
            if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1001)
        }
    }

    private fun requestRootAsync() {
        Thread {
            val ok = RootManager.check()
            runOnUiThread {
                val msg = if (ok) {
                    "Root 已授权 · ${RootManager.managerName} · su=${RootManager.suPath}"
                } else {
                    "未获得 Root：终端将以普通用户运行（可在 root 管理器里授权后重启本页）"
                }
                Snackbar.make(findViewById<View>(R.id.container), msg, Snackbar.LENGTH_LONG).show()
            }
        }.start()
    }
}
